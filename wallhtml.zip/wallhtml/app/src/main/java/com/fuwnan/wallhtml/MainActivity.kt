package com.fuwnan.wallhtml

import android.app.Activity
import android.app.Dialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var sun: SunView
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var installBtn: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var fpsRow: LinearLayout
    private lateinit var modeRow: LinearLayout

    private val main = Handler(Looper.getMainLooper())
    private var busy = false

    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = DUSK
        window.navigationBarColor = DUSK
        setContentView(buildUi())
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---- UI ----

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(DUSK)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(36))
        }
        scroll.addView(col)

        col.addView(TextView(this).apply {
            text = "wallhtml"
            setTextColor(INK)
            textSize = 26f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = -0.02f
        })
        col.addView(TextView(this).apply {
            text = "File HTML atau halaman web jadi wallpaper"
            setTextColor(MUTED)
            textSize = 13f
        }, lp(top = 2))

        sun = SunView(this)
        sun.setOnClickListener {
            val now = !Store.enabled(this)
            Store.setEnabled(this, now)
            sun.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            if (now && Store.items(this).isEmpty()) toast("Tambah wallpaper dulu")
            refresh()
        }
        col.addView(sun, lp(h = dp(270), top = 8))

        statusTitle = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 38f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        }
        statusSub = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(MUTED)
            textSize = 14f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(statusTitle, lp())
        col.addView(statusSub, lp(top = 4, bottom = 22))

        installBtn = pill("Pasang di beranda") { installWallpaper() }
        col.addView(installBtn, lp(h = dp(54)))

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = "Koleksi"
            setTextColor(INK)
            textSize = 21f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        }, lp(w = 0, weight = 1f))
        head.addView(small(pill("Tambah file") { pickFile() }), lp(w = wrap))
        head.addView(small(pill("Tambah link") { askLink() }), lp(w = wrap, start = 8))
        col.addView(head, lp(top = 34, bottom = 12))

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox, lp())

        col.addView(TextView(this).apply {
            text = "Pakai .zip kalau situsmu terdiri dari banyak file (index.html dan aset)."
            setTextColor(MUTED)
            textSize = 12f
        }, lp(top = 2))

        col.addView(TextView(this).apply {
            text = "Kelancaran"
            setTextColor(INK)
            textSize = 21f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        }, lp(top = 34, bottom = 12))
        fpsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(fpsRow, lp())

        col.addView(TextView(this).apply {
            text = "Render"
            setTextColor(INK)
            textSize = 21f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        }, lp(top = 34, bottom = 12))
        modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(modeRow, lp())
        col.addView(TextView(this).apply {
            text = "Penuh mendukung WebGL dan video. Pilih Ringan hanya kalau layar wallpaper kosong. " +
                "Berlaku setelah wallpaper dipasang ulang."
            setTextColor(MUTED)
            textSize = 12f
        }, lp(top = 10))

        return scroll
    }

    private fun refresh() {
        val on = Store.enabled(this)
        val active = Store.active(this)
        sun.setUp(on)
        statusTitle.text = if (on) "Menyala" else "Mati"
        statusTitle.setTextColor(if (on) AMBER else MUTED)
        statusSub.text = when {
            !on -> "Ketuk matahari untuk menyalakan wallpaper"
            active == null -> "Tambah file atau link di bawah"
            else -> "Memutar “${active.name}”"
        }
        val installed = isInstalled()
        installBtn.text = if (installed) "Terpasang di beranda" else "Pasang di beranda"
        stylePill(installBtn, !installed)
        renderList()
        renderFps()
        renderMode()
    }

    private fun renderList() {
        listBox.removeAllViews()
        val items = Store.items(this)
        val active = Store.active(this)
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Belum ada wallpaper. Tambah file .html atau .zip, atau tempel link web."
                setTextColor(MUTED)
                textSize = 14f
                setPadding(0, dp(6), 0, dp(10))
            }, lp())
            return
        }
        for (item in items) {
            listBox.addView(row(item, item.id == active?.id), lp(bottom = 10))
        }
    }

    private fun row(item: Item, active: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(4), dp(12))
            background = rippled(rounded(SURFACE, if (active) AMBER else LINE, 18, if (active) 2f else 1f), 18)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                Store.setActive(this@MainActivity, item.id)
                refresh()
            }
        }
        val tag = TextView(this).apply {
            text = when (item.kind) {
                Store.KIND_WEB -> "web"
                Store.KIND_ZIP -> "zip"
                else -> "html"
            }
            setTextColor(if (active) DUSK else MUTED)
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(4), dp(9), dp(4))
            background = rounded(if (active) AMBER else LINE, null, 99)
        }
        box.addView(tag, lp(w = wrap, end = 12))

        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(TextView(this).apply {
            text = item.name
            setTextColor(INK)
            textSize = 15f
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(TextView(this).apply {
            text = if (item.isWeb) item.src.removePrefix("https://").removePrefix("http://") else "Tersimpan di ponsel"
            setTextColor(MUTED)
            textSize = 12f
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
        })
        box.addView(mid, lp(w = 0, weight = 1f))

        val del = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            textSize = 24f
            setTextColor(MUTED)
            isClickable = true
            isFocusable = true
            contentDescription = "Hapus ${item.name}"
            setOnClickListener { askDelete(item) }
        }
        box.addView(del, LinearLayout.LayoutParams(dp(44), dp(44)))
        return box
    }

    private fun renderFps() {
        fpsRow.removeAllViews()
        val cur = Store.fps(this)
        val opts = listOf("Hemat" to 20, "Normal" to 30, "Halus" to 60)
        for ((i, o) in opts.withIndex()) {
            val name = o.first
            val v = o.second
            val selected = v == cur
            val t = TextView(this).apply {
                text = "$name\n$v fps"
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(if (selected) DUSK else MUTED)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = rippled(rounded(if (selected) AMBER else SURFACE, if (selected) null else LINE, 14), 14)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    Store.setFps(this@MainActivity, v)
                    renderFps()
                }
            }
            fpsRow.addView(t, lp(w = 0, weight = 1f, start = if (i == 0) 0 else 8))
        }
    }

    private fun renderMode() {
        modeRow.removeAllViews()
        val cur = Store.mode(this)
        val opts = listOf(
            "Penuh\nWebGL dan video" to Store.MODE_AUTO,
            "Ringan\nTanpa WebGL" to Store.MODE_CANVAS
        )
        for ((i, o) in opts.withIndex()) {
            val label = o.first
            val value = o.second
            val selected = value == cur
            val t = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(if (selected) DUSK else MUTED)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = rippled(rounded(if (selected) AMBER else SURFACE, if (selected) null else LINE, 14), 14)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    Store.setMode(this@MainActivity, value)
                    renderMode()
                }
            }
            modeRow.addView(t, lp(w = 0, weight = 1f, start = if (i == 0) 0 else 8))
        }
    }

    // ---- aksi ----

    private fun isInstalled(): Boolean = try {
        val info = WallpaperManager.getInstance(this).wallpaperInfo
        info != null && info.packageName == packageName &&
            info.serviceName == HtmlWallpaperService::class.java.name
    } catch (e: Throwable) {
        false
    }

    private fun installWallpaper() {
        if (Store.items(this).isEmpty()) {
            toast("Tambah wallpaper dulu")
            return
        }
        Store.setEnabled(this, true)
        refresh()
        val comp = ComponentName(this, HtmlWallpaperService::class.java)
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                toast("Buka Setelan, Wallpaper, Wallpaper live, lalu pilih wallhtml")
            }
        }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("Pemilih file tidak tersedia di ponsel ini")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            data?.data?.let { importUri(it) }
        }
    }

    private fun importUri(uri: Uri) {
        if (busy) {
            toast("Masih mengimpor file sebelumnya")
            return
        }
        busy = true
        toast("Mengimpor file")
        val app = applicationContext
        Thread {
            var err: String? = null
            val item: Item? = try {
                Importer.fromUri(app, uri)
            } catch (e: Throwable) {
                err = e.message ?: "Gagal mengimpor file"
                null
            }
            main.post {
                busy = false
                if (item != null) {
                    Store.add(app, item)
                    toast("“${item.name}” ditambahkan")
                } else {
                    toast(err ?: "Gagal mengimpor file")
                }
                if (!isFinishing && !isDestroyed) refresh()
            }
        }.start()
    }

    private fun askLink() {
        sheet("Tambah link web", "Halaman ini akan tampil sebagai wallpaper.", "https://contoh.com", "Simpan") { raw ->
            val url = Importer.normalizeUrl(raw)
            if (url == null) {
                toast("Link tidak valid. Contoh: https://contoh.com")
                false
            } else {
                val host = (Uri.parse(url).host ?: url).removePrefix("www.")
                Store.add(this, Item(Importer.newId(), host, Store.KIND_WEB, url))
                refresh()
                true
            }
        }
    }

    private fun askDelete(item: Item) {
        sheet("Hapus “${item.name}”?", "Wallpaper ini dihapus dari ponsel.", null, "Hapus") {
            Store.remove(this, item.id)
            val app = applicationContext
            Thread { Importer.delete(app, item.id) }.start()
            refresh()
            true
        }
    }

    private fun sheet(
        title: String,
        message: String?,
        placeholder: String?,
        okLabel: String,
        onOk: (String) -> Boolean
    ) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(18))
            background = rounded(SURFACE, LINE, 24)
        }
        box.addView(TextView(this).apply {
            text = title
            setTextColor(INK)
            textSize = 21f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        })
        if (message != null) {
            box.addView(TextView(this).apply {
                text = message
                setTextColor(MUTED)
                textSize = 14f
            }, lp(top = 8))
        }
        val input: EditText? = if (placeholder != null) {
            EditText(this).apply {
                hint = placeholder
                setHintTextColor(MUTED)
                setTextColor(INK)
                textSize = 15f
                setSingleLine()
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                imeOptions = EditorInfo.IME_ACTION_DONE
                background = rounded(DUSK, LINE, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
        } else {
            null
        }
        if (input != null) box.addView(input, lp(top = 14))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val cancel = pill("Batal") { d.dismiss() }
        val ok = pill(okLabel) {
            if (onOk(input?.text?.toString().orEmpty())) d.dismiss()
        }
        stylePill(ok, true)
        actions.addView(cancel, lp(w = wrap))
        actions.addView(ok, lp(w = wrap, start = 10))
        box.addView(actions, lp(top = 18))

        d.setContentView(box)
        val width = (resources.displayMetrics.widthPixels * 0.88f).toInt()
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            if (input != null) setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        d.show()
        input?.requestFocus()
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    // ---- helper tampilan ----

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun lp(
        w: Int = match,
        h: Int = wrap,
        top: Int = 0,
        bottom: Int = 0,
        start: Int = 0,
        end: Int = 0,
        weight: Float = 0f
    ): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply {
            setMargins(dp(start), dp(top), dp(end), dp(bottom))
        }

    private fun rounded(fill: Int, stroke: Int?, radiusDp: Int, strokeDp: Float = 1f): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(strokeDp), stroke)
        }

    private fun rippled(bg: Drawable, radiusDp: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, rounded(Color.WHITE, null, radiusDp))

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(20), dp(12), dp(20), dp(12))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        stylePill(this, false)
    }

    private fun small(tv: TextView): TextView {
        tv.textSize = 13f
        tv.setPadding(dp(14), dp(8), dp(14), dp(8))
        return tv
    }

    private fun stylePill(tv: TextView, filled: Boolean) {
        tv.setTextColor(if (filled) DUSK else INK)
        tv.background = rippled(
            rounded(if (filled) AMBER else Color.TRANSPARENT, if (filled) null else LINE, 99),
            99
        )
    }

    private companion object {
        const val REQ_PICK = 4201
    }
}
