package com.fuwnan.wallhtml

internal val DUSK = 0xFF15132E.toInt()
internal val SURFACE = 0xFF201D43.toInt()
internal val LINE = 0xFF332F66.toInt()
internal val INK = 0xFFF4EFFA.toInt()
internal val MUTED = 0xFF9B96C4.toInt()
internal val AMBER = 0xFFFFC06B.toInt()
internal val ROSE = 0xFFFF6F91.toInt()

internal fun withAlpha(color: Int, alpha: Int): Int =
    (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
