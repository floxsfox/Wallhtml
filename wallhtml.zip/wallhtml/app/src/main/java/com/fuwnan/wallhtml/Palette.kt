package com.fuwnan.wallhtml

import android.graphics.Color

internal val DUSK = 0xFF15132E.toInt()
internal val SURFACE = 0xFF201D43.toInt()
internal val LINE = 0xFF332F66.toInt()
internal val INK = 0xFFF4EFFA.toInt()
internal val MUTED = 0xFF9B96C4.toInt()
internal val AMBER = 0xFFFFC06B.toInt()
internal val ROSE = 0xFFFF6F91.toInt()

internal fun withAlpha(color: Int, alpha: Int): Int =
    (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

internal val DEEP_TOP = 0xFFFF8A4C.toInt()
internal val DEEP_BOT = 0xFFE5446D.toInt()

internal fun mix(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    fun ch(x: Int, y: Int) = (x + (y - x) * k).toInt()
    return Color.argb(
        ch(Color.alpha(a), Color.alpha(b)),
        ch(Color.red(a), Color.red(b)),
        ch(Color.green(a), Color.green(b)),
        ch(Color.blue(a), Color.blue(b))
    )
}
