package com.fuwnan.wallhtml

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Item(val id: String, val name: String, val kind: String, val src: String) {
    val isWeb: Boolean get() = kind == Store.KIND_WEB
}

object Store {
    const val KIND_HTML = "html"
    const val KIND_ZIP = "zip"
    const val KIND_WEB = "web"

    const val MODE_AUTO = "auto"
    const val MODE_CANVAS = "canvas"

    private const val FILE = "wallhtml"
    private const val K_ITEMS = "items"
    private const val K_ACTIVE = "active"
    private const val K_ENABLED = "enabled"
    private const val K_FPS = "fps"
    private const val K_MODE = "mode"

    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun items(c: Context): List<Item> {
        val raw = prefs(c).getString(K_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Item(o.getString("id"), o.getString("name"), o.getString("kind"), o.getString("src"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun encode(list: List<Item>): String {
        val arr = JSONArray()
        for (item in list) {
            arr.put(
                JSONObject()
                    .put("id", item.id)
                    .put("name", item.name)
                    .put("kind", item.kind)
                    .put("src", item.src)
            )
        }
        return arr.toString()
    }

    fun active(c: Context): Item? {
        val list = items(c)
        val id = prefs(c).getString(K_ACTIVE, null)
        return list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }

    fun add(c: Context, item: Item) {
        val list = items(c) + item
        prefs(c).edit()
            .putString(K_ITEMS, encode(list))
            .putString(K_ACTIVE, item.id)
            .apply()
    }

    fun remove(c: Context, id: String) {
        val list = items(c).filter { it.id != id }
        val p = prefs(c)
        val ed = p.edit().putString(K_ITEMS, encode(list))
        if (p.getString(K_ACTIVE, null) == id) {
            ed.putString(K_ACTIVE, list.firstOrNull()?.id ?: "")
        }
        ed.apply()
    }

    fun setActive(c: Context, id: String) {
        prefs(c).edit().putString(K_ACTIVE, id).apply()
    }

    fun enabled(c: Context): Boolean = prefs(c).getBoolean(K_ENABLED, true)

    fun setEnabled(c: Context, value: Boolean) {
        prefs(c).edit().putBoolean(K_ENABLED, value).apply()
    }

    fun fps(c: Context): Int = prefs(c).getInt(K_FPS, 30).coerceIn(10, 60)

    fun setFps(c: Context, value: Int) {
        prefs(c).edit().putInt(K_FPS, value).apply()
    }

    /** Mesin render: auto = layar virtual (WebGL, video), canvas = gambar software (ringan, tanpa WebGL). */
    fun mode(c: Context): String = prefs(c).getString(K_MODE, MODE_AUTO) ?: MODE_AUTO

    fun setMode(c: Context, value: String) {
        prefs(c).edit().putString(K_MODE, value).apply()
    }
}
