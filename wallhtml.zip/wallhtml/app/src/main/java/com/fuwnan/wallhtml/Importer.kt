package com.fuwnan.wallhtml

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipInputStream

object Importer {
    private const val MAX_BYTES = 300L * 1024 * 1024
    private const val MAX_FILES = 5000

    fun newId(): String = UUID.randomUUID().toString().replace("-", "").substring(0, 12)

    fun sitesDir(c: Context): File = File(c.filesDir, "sites")

    fun siteDir(c: Context, id: String): File = File(sitesDir(c), id)

    fun delete(c: Context, id: String) {
        try {
            siteDir(c, id).deleteRecursively()
        } catch (e: Exception) {
            // abaikan, folder sisa tidak mengganggu
        }
    }

    fun normalizeUrl(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty() || s.any { it.isWhitespace() }) return null
        if (!s.contains("://")) s = "https://$s"
        val u = Uri.parse(s)
        val scheme = u.scheme?.lowercase()
        val host = u.host
        if (scheme != "http" && scheme != "https") return null
        if (host.isNullOrBlank()) return null
        if (!host.contains('.') && host != "localhost") return null
        return s
    }

    /** Salin file .html atau ekstrak .zip ke penyimpanan internal app, lalu kembalikan Item-nya. */
    fun fromUri(c: Context, uri: Uri): Item {
        val fileName = displayName(c, uri)
        val lower = fileName.lowercase()
        val isZip = lower.endsWith(".zip")
        val isHtml = lower.endsWith(".html") || lower.endsWith(".htm")
        if (!isZip && !isHtml) throw IOException("Pilih file .html atau .zip")

        val id = newId()
        val dir = siteDir(c, id)
        try {
            if (!dir.mkdirs()) throw IOException("Gagal membuat folder penyimpanan")
            val entry = if (isHtml) copyHtml(c, uri, dir) else unzip(c, uri, dir)
            val base = fileName.substringBeforeLast('.', fileName).ifBlank { "wallpaper" }
            return Item(id, base, if (isZip) Store.KIND_ZIP else Store.KIND_HTML, entry)
        } catch (e: Throwable) {
            dir.deleteRecursively()
            throw e
        }
    }

    private fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) {
                        val n = cur.getString(i)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            }
        } catch (e: Exception) {
            // jatuh ke nama cadangan
        }
        return uri.lastPathSegment ?: "wallpaper"
    }

    private fun copyHtml(c: Context, uri: Uri, dir: File): String {
        val input = c.contentResolver.openInputStream(uri) ?: throw IOException("Gagal membuka file")
        input.use { ins ->
            FileOutputStream(File(dir, "index.html")).use { out -> ins.copyTo(out) }
        }
        return "index.html"
    }

    private fun unzip(c: Context, uri: Uri, dir: File): String {
        val input = c.contentResolver.openInputStream(uri) ?: throw IOException("Gagal membuka file")
        val root = dir.canonicalPath + File.separator
        var total = 0L
        var count = 0
        ZipInputStream(input.buffered()).use { zin ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val e = zin.nextEntry ?: break
                val name = e.name.replace('\\', '/')
                if (name.startsWith("__MACOSX")) continue
                val out = File(dir, name)
                if (!out.canonicalPath.startsWith(root)) throw IOException("ZIP tidak valid")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    count++
                    if (count > MAX_FILES) throw IOException("ZIP berisi terlalu banyak file")
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos ->
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_BYTES) throw IOException("ZIP terlalu besar")
                            fos.write(buf, 0, n)
                        }
                    }
                }
            }
        }
        return findEntry(dir) ?: throw IOException("ZIP tidak berisi file .html")
    }

    private fun findEntry(dir: File): String? {
        val files = dir.walkTopDown()
            .filter { it.isFile && (it.extension.equals("html", true) || it.extension.equals("htm", true)) }
            .map { it.relativeTo(dir).invariantSeparatorsPath }
            .toList()
        if (files.isEmpty()) return null
        val index = files.filter { it.substringAfterLast('/').equals("index.html", true) }
        val pool = if (index.isEmpty()) files else index
        return pool.minWithOrNull(compareBy<String>({ p -> p.count { ch -> ch == '/' } }, { p -> p }))
    }
}
