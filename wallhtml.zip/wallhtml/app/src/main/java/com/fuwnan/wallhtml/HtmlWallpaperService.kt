package com.fuwnan.wallhtml

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.io.File
import kotlin.math.min

class HtmlWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = HtmlEngine()

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        const val NO_SCROLL_JS =
            "(function(){var d=document.documentElement;d.style.overflow='hidden';" +
                "if(document.body){document.body.style.overflow='hidden';}})();"

        /** Jumlah engine yang sedang terlihat (preview + beranda), dipakai untuk jeda timer JS. */
        var visibleEngines = 0
    }

    private inner class HtmlEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private val ctx: Context = this@HtmlWallpaperService.applicationContext

        private var web: WebView? = null
        private var loadedId: String? = null
        private var currentUrl = ""
        private var loadFailed = false
        private var idleText = ""
        private var visible = false
        private var surfaceReady = false
        private var destroyed = false
        private var w = 0
        private var h = 0
        private var frameMs = 33L

        private val idleSun = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE }
        private val idleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = LINE
        }
        private val idleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = MUTED
            textAlign = Paint.Align.CENTER
        }

        private val prefListener =
            SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> handler.post { applyState() } }

        private val frame = object : Runnable {
            override fun run() {
                if (destroyed || !visible || !surfaceReady) return
                val t0 = SystemClock.uptimeMillis()
                drawFrame()
                if (web != null && !loadFailed) {
                    val wait = frameMs - (SystemClock.uptimeMillis() - t0)
                    handler.postDelayed(this, if (wait < 1L) 1L else wait)
                }
            }
        }

        private val retry = Runnable {
            val wv = web
            if (!destroyed && wv != null && loadFailed) {
                loadFailed = false
                wv.loadUrl(currentUrl)
                syncLoop()
            }
        }

        override fun onCreate(sh: SurfaceHolder?) {
            super.onCreate(sh)
            setTouchEventsEnabled(true)
            Store.prefs(ctx).registerOnSharedPreferenceChangeListener(prefListener)
            applyState()
        }

        override fun onDestroy() {
            destroyed = true
            handler.removeCallbacksAndMessages(null)
            Store.prefs(ctx).unregisterOnSharedPreferenceChangeListener(prefListener)
            if (visible) {
                visible = false
                visibleEngines--
            }
            releaseWeb()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceReady = true
            if (width != w || height != h) {
                w = width
                h = height
                web?.let { layoutWeb(it) }
            }
            applyState()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            surfaceReady = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (destroyed || this.visible == visible) return
            this.visible = visible
            val wv = web
            if (visible) {
                visibleEngines++
                wv?.onResume()
                wv?.resumeTimers()
            } else {
                visibleEngines--
                wv?.onPause()
                if (visibleEngines <= 0) wv?.pauseTimers()
            }
            syncLoop()
        }

        override fun onTouchEvent(event: MotionEvent?) {
            super.onTouchEvent(event)
            val wv = web ?: return
            if (event == null || loadFailed) return
            val copy = MotionEvent.obtain(event)
            try {
                wv.dispatchTouchEvent(copy)
            } catch (e: Throwable) {
                // abaikan sentuhan yang gagal
            } finally {
                copy.recycle()
            }
        }

        // ---- state ----

        private fun applyState() {
            if (destroyed) return
            val enabled = Store.enabled(ctx)
            val item = Store.active(ctx)
            frameMs = 1000L / Store.fps(ctx)

            if (!enabled || item == null || w <= 0 || h <= 0) {
                releaseWeb()
                idleText = when {
                    !enabled -> "wallhtml dimatikan"
                    item == null -> "Belum ada wallpaper"
                    else -> ""
                }
            } else if (web == null || loadedId != item.id) {
                releaseWeb()
                startWeb(item)
            }
            syncLoop()
        }

        private fun fail(item: Item, message: String) {
            loadedId = item.id
            idleText = message
            loadFailed = true
        }

        private fun startWeb(item: Item) {
            val url: String
            var loader: WebViewAssetLoader? = null
            if (item.isWeb) {
                url = item.src
            } else {
                val dir = Importer.siteDir(ctx, item.id)
                if (!File(dir, item.src).isFile) {
                    fail(item, "File wallpaper tidak ditemukan")
                    return
                }
                loader = try {
                    WebViewAssetLoader.Builder()
                        .setDomain(HOST)
                        .addPathHandler("/site/", WebViewAssetLoader.InternalStoragePathHandler(ctx, dir))
                        .build()
                } catch (e: Exception) {
                    fail(item, "Gagal membuka file wallpaper")
                    return
                }
                url = Uri.Builder().scheme("https").authority(HOST).path("/site/" + item.src).build().toString()
            }

            val wv = try {
                WebView(ctx)
            } catch (e: Throwable) {
                fail(item, "WebView tidak tersedia di ponsel ini")
                return
            }

            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                useWideViewPort = false
                loadWithOverviewMode = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            wv.isVerticalScrollBarEnabled = false
            wv.isHorizontalScrollBarEnabled = false
            wv.overScrollMode = View.OVER_SCROLL_NEVER
            wv.setBackgroundColor(Color.BLACK)
            wv.webViewClient = client(loader)
            layoutWeb(wv)

            web = wv
            loadedId = item.id
            currentUrl = url
            loadFailed = false
            if (visible) {
                wv.onResume()
                wv.resumeTimers()
            } else {
                wv.onPause()
            }
            wv.loadUrl(url)
        }

        private fun layoutWeb(wv: WebView) {
            wv.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
            )
            wv.layout(0, 0, w, h)
        }

        private fun client(loader: WebViewAssetLoader?): WebViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader?.shouldInterceptRequest(u)
            }

            // Ketukan pada link di wallpaper tidak boleh memindahkan halaman.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return request != null && request.isForMainFrame && request.hasGesture()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(NO_SCROLL_JS, null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame) handlePageError()
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                handler.postDelayed({ restartWeb() }, 1500L)
                return true
            }
        }

        private fun handlePageError() {
            if (loadFailed || destroyed) return
            loadFailed = true
            idleText = "Tidak bisa memuat, mencoba lagi otomatis"
            handler.removeCallbacks(retry)
            handler.postDelayed(retry, 30_000L)
            handler.post { if (!destroyed) web?.loadUrl("about:blank") }
            syncLoop()
        }

        private fun restartWeb() {
            if (destroyed) return
            releaseWeb()
            applyState()
        }

        private fun releaseWeb() {
            handler.removeCallbacks(retry)
            loadFailed = false
            loadedId = null
            val wv = web ?: return
            web = null
            try {
                wv.webViewClient = WebViewClient()
                wv.stopLoading()
                wv.onPause()
                wv.destroy()
            } catch (e: Throwable) {
                // WebView sudah mati, tidak apa-apa
            }
        }

        // ---- gambar ----

        private fun syncLoop() {
            handler.removeCallbacks(frame)
            if (destroyed || !visible || !surfaceReady) return
            if (web != null && !loadFailed) {
                handler.post(frame)
            } else {
                drawFrame()
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val wv = web
                if (wv != null && !loadFailed) {
                    canvas.drawColor(Color.BLACK)
                    wv.computeScroll()
                    wv.draw(canvas)
                } else {
                    drawIdle(canvas)
                }
            } catch (e: Throwable) {
                // lewati satu frame yang gagal
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Throwable) {
                        // surface sudah hilang
                    }
                }
            }
        }

        /** Layar saat wallpaper mati, kosong, atau gagal: matahari terbenam. */
        private fun drawIdle(c: Canvas) {
            val cw = c.width.toFloat()
            val ch = c.height.toFloat()
            c.drawColor(DUSK)
            val hy = ch * 0.58f
            val r = min(cw, ch) * 0.13f
            c.save()
            c.clipRect(0f, 0f, cw, hy)
            c.drawCircle(cw / 2f, hy + r * 0.25f, r, idleSun)
            c.restore()
            idleLine.strokeWidth = cw * 0.004f
            c.drawLine(cw * 0.2f, hy, cw * 0.8f, hy, idleLine)
            idleTextPaint.textSize = cw * 0.038f
            if (idleText.isNotEmpty()) {
                c.drawText(idleText, cw / 2f, hy + idleTextPaint.textSize * 2.4f, idleTextPaint)
            }
        }
    }
}
