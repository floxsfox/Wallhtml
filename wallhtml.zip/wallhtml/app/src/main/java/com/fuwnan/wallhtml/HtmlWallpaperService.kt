package com.fuwnan.wallhtml

import android.app.WallpaperManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File
import kotlin.math.min

class HtmlWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = HtmlEngine()

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        /** Mengunci scroll lewat CSS supaya halaman wallpaper tidak bergeser. */
        const val LOCK_JS = """
(function(){
  if(document.getElementById('__whlock'))return;
  var s=document.createElement('style');s.id='__whlock';
  s.textContent='html,body{overflow:hidden!important;overscroll-behavior:none!important}';
  (document.head||document.documentElement).appendChild(s);
})();
"""

        /**
         * requestAnimationFrame cadangan. WebView di wallpaper tidak menempel ke jendela, jadi detak
         * frame bawaan bisa tidak jalan. Callback tetap memakai detak bawaan kalau hidup; kalau
         * telat, dijalankan lewat timer sesuai fps supaya animasi JavaScript tidak berhenti.
         */
        const val RAF_SHIM_JS = """
(function(){
  if(window.__whRaf)return;window.__whRaf=1;
  var nRaf=window.requestAnimationFrame,nCaf=window.cancelAnimationFrame;
  if(!nRaf||!nCaf)return;
  var seq=0,pend={};
  function wait(){return Math.max(50,(window.__whFrameMs||33)*1.6);}
  window.requestAnimationFrame=function(cb){
    var id=++seq,p={done:false};
    function run(t){
      if(p.done)return;p.done=true;clearTimeout(p.tid);delete pend[id];
      cb(typeof t==='number'?t:performance.now());
    }
    p.nid=nRaf.call(window,run);
    p.tid=setTimeout(function(){
      if(p.done)return;
      try{nCaf.call(window,p.nid);}catch(e){}
      run(performance.now());
    },wait());
    pend[id]=p;
    return id;
  };
  window.cancelAnimationFrame=function(id){
    var p=pend[id];if(!p)return;
    p.done=true;clearTimeout(p.tid);
    try{nCaf.call(window,p.nid);}catch(e){}
    delete pend[id];
  };
})();
"""

        /**
         * Jembatan sentuhan (window.__wh): meneruskan sentuhan wallpaper sebagai event pointer,
         * touch, dan mouse ke halaman.
         */
        const val BRIDGE_JS = """
(function(){
  if(window.__wh)return;
  var act={},prim=null,g=null;
  function cnt(){var n=0;for(var k in act)n++;return n;}
  function tgt(x,y){return document.elementFromPoint(x,y)||document.body||document.documentElement;}
  function send(el,ev){try{return el.dispatchEvent(ev);}catch(e){return true;}}
  function ptr(type,a,isP){
    var up=(type==='pointerup'||type==='pointercancel');
    try{return send(a.el,new PointerEvent(type,{bubbles:true,cancelable:true,composed:true,
      pointerId:a.id+1,pointerType:'touch',isPrimary:isP,clientX:a.x,clientY:a.y,screenX:a.x,screenY:a.y,
      pressure:up?0:0.5,width:1,height:1,button:type==='pointermove'?-1:0,buttons:up?0:1}));}
    catch(e){return true;}
  }
  function mk(o){
    return new Touch({identifier:o.id,target:o.el,clientX:o.x,clientY:o.y,
      pageX:o.x+window.scrollX,pageY:o.y+window.scrollY,screenX:o.x,screenY:o.y});
  }
  function touch(type,a){
    try{
      var all=[];for(var k in act)all.push(mk(act[k]));
      var ending=(type==='touchend'||type==='touchcancel');
      var live=ending?all.filter(function(t){return t.identifier!==a.id;}):all;
      return send(a.el,new TouchEvent(type,{bubbles:true,cancelable:true,composed:true,touches:live,
        targetTouches:live.filter(function(t){return t.target===a.el;}),changedTouches:[mk(a)]}));
    }catch(e){return true;}
  }
  function mouse(type,a,bs){
    try{return send(a.el,new MouseEvent(type,{bubbles:true,cancelable:true,composed:true,
      clientX:a.x,clientY:a.y,screenX:a.x,screenY:a.y,button:0,buttons:bs,view:window}));}
    catch(e){return true;}
  }
  window.__wh=function(type,id,x,y){
    if(type==='x'){act={};prim=null;g=null;return;}
    var a=act[id];
    if(type==='d'){
      var first=(cnt()===0);
      a=act[id]={id:id,x:x,y:y,el:tgt(x,y)};
      if(first){prim=id;g={sx:x,sy:y,t:Date.now(),moved:false,noMouse:false};}
      ptr('pointerdown',a,first);
      var ok=touch('touchstart',a);
      if(first){
        if(ok===false)g.noMouse=true;
        if(!g.noMouse){mouse('mousemove',a,0);mouse('mousedown',a,1);}
      }
      return;
    }
    if(!a)return;
    a.x=x;a.y=y;
    var isP=(id===prim);
    if(type==='m'){
      if(isP&&g&&(Math.abs(x-g.sx)>10||Math.abs(y-g.sy)>10))g.moved=true;
      ptr('pointermove',a,isP);
      touch('touchmove',a);
      if(isP&&g&&!g.noMouse)mouse('mousemove',a,1);
      return;
    }
    var cancel=(type==='c');
    ptr(cancel?'pointercancel':'pointerup',a,isP);
    touch(cancel?'touchcancel':'touchend',a);
    if(isP&&g){
      if(!g.noMouse){
        mouse('mouseup',a,0);
        if(!cancel&&!g.moved&&Date.now()-g.t<600){a.el=tgt(x,y);mouse('click',a,0);}
      }
      g=null;prim=null;
    }
    delete act[id];
  };
})();
"""

        /** Jumlah engine yang sedang terlihat (preview + beranda), dipakai untuk jeda timer JS. */
        var visibleEngines = 0
    }

    private inner class HtmlEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private val ctx: Context = this@HtmlWallpaperService.applicationContext

        private var web: WebView? = null
        private var loadedId: String? = null
        private var currentUrl = ""
        private var loadFailed = false
        private var idleText = ""
        private var visible = false
        private var surfaceReady = false
        private var destroyed = false
        private var w = 0
        private var h = 0
        private var frameMs = 33L
        private var lastTouchAt = 0L
        private var lastMoveAt = 0L
        private var docStartOk = false
        private val density = ctx.resources.displayMetrics.density

        private val idleSun = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE }
        private val idleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = LINE
        }
        private val idleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = MUTED
            textAlign = Paint.Align.CENTER
        }

        private val prefListener =
            SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> handler.post { applyState() } }

        private val frame = object : Runnable {
            override fun run() {
                if (destroyed || !visible || !surfaceReady) return
                val t0 = SystemClock.uptimeMillis()
                drawFrame()
                if (web != null && !loadFailed) {
                    val wait = frameMs - (SystemClock.uptimeMillis() - t0)
                    handler.postDelayed(this, if (wait < 1L) 1L else wait)
                }
            }
        }

        private val retry = Runnable {
            val wv = web
            if (!destroyed && wv != null && loadFailed) {
                loadFailed = false
                wv.loadUrl(currentUrl)
                syncLoop()
            }
        }

        override fun onCreate(sh: SurfaceHolder?) {
            super.onCreate(sh)
            setTouchEventsEnabled(true)
            Store.prefs(ctx).registerOnSharedPreferenceChangeListener(prefListener)
            applyState()
        }

        override fun onDestroy() {
            destroyed = true
            handler.removeCallbacksAndMessages(null)
            Store.prefs(ctx).unregisterOnSharedPreferenceChangeListener(prefListener)
            if (visible) {
                visible = false
                visibleEngines--
            }
            releaseWeb()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceReady = true
            if (width != w || height != h) {
                w = width
                h = height
                web?.let { layoutWeb(it) }
            }
            applyState()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            surfaceReady = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (destroyed || this.visible == visible) return
            this.visible = visible
            val wv = web
            if (visible) {
                visibleEngines++
                wv?.dispatchWindowVisibilityChanged(View.VISIBLE)
                wv?.onResume()
                wv?.resumeTimers()
            } else {
                visibleEngines--
                wv?.evaluateJavascript("if(window.__wh)__wh('x');", null)
                wv?.onPause()
                wv?.dispatchWindowVisibilityChanged(View.GONE)
                if (visibleEngines <= 0) wv?.pauseTimers()
            }
            syncLoop()
        }

        /**
         * Wallpaper hanya menerima salinan sentuhan dari launcher dan tidak pernah menahannya,
         * jadi geser halaman beranda tetap jalan normal sementara halaman web ikut bereaksi.
         */
        override fun onTouchEvent(event: MotionEvent?) {
            super.onTouchEvent(event)
            if (event == null || web == null || loadFailed) return
            lastTouchAt = SystemClock.uptimeMillis()
            try {
                forward(event)
            } catch (e: Throwable) {
                // abaikan sentuhan yang gagal
            }
        }

        /** Launcher yang tidak meneruskan sentuhan mentah tetap mengirim ketukan lewat perintah ini. */
        override fun onCommand(
            action: String?,
            x: Int,
            y: Int,
            z: Int,
            extras: Bundle?,
            resultRequested: Boolean
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP && web != null && !loadFailed &&
                SystemClock.uptimeMillis() - lastTouchAt > 800L
            ) {
                tap(x / density, y / density)
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        private fun tap(cssX: Float, cssY: Float) {
            val wv = web ?: return
            wv.evaluateJavascript("if(window.__wh){__wh('x');__wh('d',100,$cssX,$cssY);}", null)
            handler.postDelayed({
                if (!destroyed) {
                    web?.evaluateJavascript("if(window.__wh){__wh('u',100,$cssX,$cssY);}", null)
                }
            }, 60L)
        }

        private fun forward(event: MotionEvent) {
            val wv = web ?: return
            val sb = StringBuilder("if(window.__wh){")
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sb.append("__wh('x');")
                    appendPointer(sb, 'd', event, 0)
                }
                MotionEvent.ACTION_POINTER_DOWN -> appendPointer(sb, 'd', event, event.actionIndex)
                MotionEvent.ACTION_MOVE -> {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastMoveAt < 12L) return
                    lastMoveAt = now
                    for (i in 0 until event.pointerCount) appendPointer(sb, 'm', event, i)
                }
                MotionEvent.ACTION_POINTER_UP,
                MotionEvent.ACTION_UP -> appendPointer(sb, 'u', event, event.actionIndex)
                MotionEvent.ACTION_CANCEL -> {
                    for (i in 0 until event.pointerCount) appendPointer(sb, 'c', event, i)
                    sb.append("__wh('x');")
                }
                else -> return
            }
            sb.append('}')
            wv.evaluateJavascript(sb.toString(), null)
        }

        private fun appendPointer(sb: StringBuilder, type: Char, e: MotionEvent, index: Int) {
            sb.append("__wh('").append(type).append("',")
                .append(e.getPointerId(index)).append(',')
                .append(e.getX(index) / density).append(',')
                .append(e.getY(index) / density).append(");")
        }

        // ---- state ----

        private fun applyState() {
            if (destroyed) return
            val enabled = Store.enabled(ctx)
            val item = Store.active(ctx)
            val ms = 1000L / Store.fps(ctx)
            if (ms != frameMs) {
                frameMs = ms
                web?.evaluateJavascript("window.__whFrameMs=$frameMs;", null)
            }

            if (!enabled || item == null || w <= 0 || h <= 0) {
                releaseWeb()
                idleText = when {
                    !enabled -> "wallhtml dimatikan"
                    item == null -> "Belum ada wallpaper"
                    else -> ""
                }
            } else if (web == null || loadedId != item.id) {
                releaseWeb()
                startWeb(item)
            }
            syncLoop()
        }

        private fun fail(item: Item, message: String) {
            loadedId = item.id
            idleText = message
            loadFailed = true
        }

        private fun startWeb(item: Item) {
            val url: String
            var loader: WebViewAssetLoader? = null
            if (item.isWeb) {
                url = item.src
            } else {
                val dir = Importer.siteDir(ctx, item.id)
                if (!File(dir, item.src).isFile) {
                    fail(item, "File wallpaper tidak ditemukan")
                    return
                }
                loader = try {
                    WebViewAssetLoader.Builder()
                        .setDomain(HOST)
                        .addPathHandler("/site/", WebViewAssetLoader.InternalStoragePathHandler(ctx, dir))
                        .build()
                } catch (e: Exception) {
                    fail(item, "Gagal membuka file wallpaper")
                    return
                }
                url = Uri.Builder().scheme("https").authority(HOST).path("/site/" + item.src).build().toString()
            }

            val wv = try {
                WebView(ctx)
            } catch (e: Throwable) {
                fail(item, "WebView tidak tersedia di ponsel ini")
                return
            }

            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                useWideViewPort = false
                loadWithOverviewMode = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            wv.isVerticalScrollBarEnabled = false
            wv.isHorizontalScrollBarEnabled = false
            wv.overScrollMode = View.OVER_SCROLL_NEVER
            wv.setBackgroundColor(Color.BLACK)
            wv.webViewClient = client(loader)
            layoutWeb(wv)
            docStartOk = try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    WebViewCompat.addDocumentStartJavaScript(wv, RAF_SHIM_JS + BRIDGE_JS, setOf("*"))
                    true
                } else {
                    false
                }
            } catch (e: Throwable) {
                false
            }

            web = wv
            loadedId = item.id
            currentUrl = url
            loadFailed = false
            // WebView tanpa jendela dianggap tersembunyi (timer dan frame JS diperlambat),
            // jadi status jendelanya diset manual.
            if (visible) {
                wv.dispatchWindowVisibilityChanged(View.VISIBLE)
                wv.onResume()
                wv.resumeTimers()
            } else {
                wv.dispatchWindowVisibilityChanged(View.GONE)
                wv.onPause()
            }
            wv.loadUrl(url)
        }

        private fun layoutWeb(wv: WebView) {
            wv.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
            )
            wv.layout(0, 0, w, h)
        }

        private fun client(loader: WebViewAssetLoader?): WebViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader?.shouldInterceptRequest(u)
            }

            // Ketukan pada link di wallpaper tidak boleh memindahkan halaman.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return request != null && request.isForMainFrame && request.hasGesture()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (!docStartOk) view?.evaluateJavascript(RAF_SHIM_JS + BRIDGE_JS, null)
                view?.evaluateJavascript("window.__whFrameMs=$frameMs;", null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(LOCK_JS + BRIDGE_JS, null)
                view?.evaluateJavascript("window.__whFrameMs=$frameMs;", null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame) handlePageError()
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                handler.postDelayed({ restartWeb() }, 1500L)
                return true
            }
        }

        private fun handlePageError() {
            if (loadFailed || destroyed) return
            loadFailed = true
            idleText = "Tidak bisa memuat, mencoba lagi otomatis"
            handler.removeCallbacks(retry)
            handler.postDelayed(retry, 30_000L)
            handler.post { if (!destroyed) web?.loadUrl("about:blank") }
            syncLoop()
        }

        private fun restartWeb() {
            if (destroyed) return
            releaseWeb()
            applyState()
        }

        private fun releaseWeb() {
            handler.removeCallbacks(retry)
            loadFailed = false
            loadedId = null
            val wv = web ?: return
            web = null
            try {
                wv.webViewClient = WebViewClient()
                wv.stopLoading()
                wv.onPause()
                wv.destroy()
            } catch (e: Throwable) {
                // WebView sudah mati, tidak apa-apa
            }
        }

        // ---- gambar ----

        private fun syncLoop() {
            handler.removeCallbacks(frame)
            if (destroyed || !visible || !surfaceReady) return
            if (web != null && !loadFailed) {
                handler.post(frame)
            } else {
                drawFrame()
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val wv = web
                if (wv != null && !loadFailed) {
                    canvas.drawColor(Color.BLACK)
                    wv.computeScroll()
                    wv.draw(canvas)
                } else {
                    drawIdle(canvas)
                }
            } catch (e: Throwable) {
                // lewati satu frame yang gagal
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Throwable) {
                        // surface sudah hilang
                    }
                }
            }
        }

        /** Layar saat wallpaper mati, kosong, atau gagal: matahari terbenam. */
        private fun drawIdle(c: Canvas) {
            val cw = c.width.toFloat()
            val ch = c.height.toFloat()
            c.drawColor(DUSK)
            val hy = ch * 0.58f
            val r = min(cw, ch) * 0.13f
            c.save()
            c.clipRect(0f, 0f, cw, hy)
            c.drawCircle(cw / 2f, hy + r * 0.25f, r, idleSun)
            c.restore()
            idleLine.strokeWidth = cw * 0.004f
            c.drawLine(cw * 0.2f, hy, cw * 0.8f, hy, idleLine)
            idleTextPaint.textSize = cw * 0.038f
            if (idleText.isNotEmpty()) {
                c.drawText(idleText, cw / 2f, hy + idleTextPaint.textSize * 2.4f, idleTextPaint)
            }
        }
    }
}
