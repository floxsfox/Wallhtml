package com.fuwnan.wallhtml

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Matahari sebagai tombol: terbit = wallpaper menyala, terbenam = mati. */
class SunView(context: Context) : View(context) {

    private var up: Boolean? = null
    private var rise = 0f
    private var spin = 0f

    private var cx = 0f
    private var hy = 0f
    private var r = 0f
    private var baseY = 0f
    private var offY = 0f

    private val density = resources.displayMetrics.density
    private val sunPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = AMBER
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private var riseAnim: ValueAnimator? = null
    private val spinAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            spin = it.animatedValue as Float
            if (rise > 0.02f) invalidate()
        }
    }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Matahari. Ketuk untuk menyalakan atau mematikan wallpaper"
    }

    fun setUp(value: Boolean) {
        val prev = up
        if (prev == value) return
        up = value
        val target = if (value) 1f else 0f
        riseAnim?.cancel()
        if (prev == null) {
            rise = target
            invalidate()
            return
        }
        riseAnim = ValueAnimator.ofFloat(rise, target).apply {
            duration = 650L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                rise = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!spinAnim.isStarted) spinAnim.start()
    }

    override fun onDetachedFromWindow() {
        spinAnim.cancel()
        riseAnim?.cancel()
        rise = if (up == true) 1f else 0f
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (!spinAnim.isStarted) spinAnim.start()
        } else {
            spinAnim.cancel()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        hy = h * 0.70f
        r = min(w.toFloat(), h.toFloat()) * 0.26f
        baseY = hy - r * 1.2f
        offY = hy + r * 0.92f

        sunPaint.shader = LinearGradient(cx, baseY - r, cx, baseY + r, AMBER, ROSE, Shader.TileMode.CLAMP)
        haloPaint.shader = RadialGradient(
            cx, baseY, r * 2.3f,
            intArrayOf(withAlpha(ROSE, 120), withAlpha(ROSE, 0)),
            floatArrayOf(0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        linePaint.strokeWidth = 1.5f * density
        linePaint.shader = LinearGradient(
            0f, hy, w.toFloat(), hy,
            intArrayOf(withAlpha(LINE, 0), LINE, withAlpha(LINE, 0)),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        rayPaint.strokeWidth = 2.6f * density
    }

    override fun onDraw(c: Canvas) {
        if (r <= 0f) return
        val w = width.toFloat()

        c.save()
        c.clipRect(0f, 0f, w, hy)
        drawSun(c, 1f)
        c.restore()

        // pantulan di bawah garis horizon
        c.save()
        c.clipRect(0f, hy, w, height.toFloat())
        c.scale(1f, -1f, cx, hy)
        drawSun(c, 0.22f)
        c.restore()

        c.drawLine(0f, hy, w, hy, linePaint)
    }

    private fun drawSun(c: Canvas, k: Float) {
        val dy = (1f - rise) * (offY - baseY)
        c.save()
        c.translate(0f, dy)
        if (rise > 0.01f) {
            haloPaint.alpha = (255 * rise * k).toInt()
            c.drawCircle(cx, baseY, r * 2.3f, haloPaint)

            rayPaint.alpha = (190 * rise * k).toInt()
            val shift = Math.toRadians((spin * 15f).toDouble())
            for (i in 0 until 24) {
                val a = shift + i * (Math.PI * 2.0 / 24.0)
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                val r1 = r * 1.2f
                val r2 = r * (if (i % 2 == 0) 1.5f else 1.36f)
                c.drawLine(cx + ca * r1, baseY + sa * r1, cx + ca * r2, baseY + sa * r2, rayPaint)
            }
        }
        sunPaint.alpha = (255 * k * (0.28f + 0.72f * rise)).toInt()
        c.drawCircle(cx, baseY, r, sunPaint)
        c.restore()
    }
}
