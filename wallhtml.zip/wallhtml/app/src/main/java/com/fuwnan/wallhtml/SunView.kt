package com.fuwnan.wallhtml

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Tombol berbentuk matahari. Menyala: matahari terbit di atas horizon dengan langit hangat dan sinar.
 * Mati: matahari tenggelam di balik horizon, langit malam dengan bintang berkelip.
 */
class SunView(context: Context) : View(context) {

    private var up: Boolean? = null
    private var rise = 0f
    private var spin = 0f

    private var cx = 0f
    private var hy = 0f
    private var r = 0f
    private var baseY = 0f
    private var offY = 0f
    private var shaderRise = -1f

    private var starX = FloatArray(0)
    private var starY = FloatArray(0)
    private var starR = FloatArray(0)
    private var starPh = FloatArray(0)

    private val density = resources.displayMetrics.density
    private val sunPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val domePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emberPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK }
    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = AMBER
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private var riseAnim: ValueAnimator? = null
    private val spinAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            spin = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Matahari. Ketuk untuk menyalakan atau mematikan wallpaper"
    }

    fun setUp(value: Boolean) {
        val prev = up
        if (prev == value) return
        up = value
        val target = if (value) 1f else 0f
        riseAnim?.cancel()
        if (prev == null) {
            rise = target
            invalidate()
            return
        }
        val full = if (value) 1900f else 1500f
        riseAnim = ValueAnimator.ofFloat(rise, target).apply {
            duration = (full * abs(target - rise)).toLong().coerceAtLeast(300L)
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                rise = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!spinAnim.isStarted) spinAnim.start()
    }

    override fun onDetachedFromWindow() {
        spinAnim.cancel()
        riseAnim?.cancel()
        rise = if (up == true) 1f else 0f
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (!spinAnim.isStarted) spinAnim.start()
        } else {
            spinAnim.cancel()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        hy = h * 0.70f
        r = min(w.toFloat(), h.toFloat()) * 0.26f
        baseY = hy - r * 1.2f
        offY = hy + r * 1.1f
        shaderRise = -1f

        haloPaint.shader = RadialGradient(
            cx, baseY, r * 2.3f,
            intArrayOf(withAlpha(ROSE, 120), withAlpha(ROSE, 0)),
            floatArrayOf(0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        domePaint.shader = RadialGradient(
            cx, hy, w * 0.5f,
            intArrayOf(withAlpha(AMBER, 150), withAlpha(ROSE, 70), withAlpha(ROSE, 0)),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        emberPaint.shader = RadialGradient(
            cx, hy, r,
            intArrayOf(withAlpha(AMBER, 90), withAlpha(AMBER, 0)),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        linePaint.strokeWidth = 1.5f * density
        linePaint.shader = LinearGradient(
            0f, hy, w.toFloat(), hy,
            intArrayOf(withAlpha(LINE, 0), LINE, withAlpha(LINE, 0)),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        rayPaint.strokeWidth = 2.6f * density

        val rnd = Random(7)
        val n = 44
        starX = FloatArray(n)
        starY = FloatArray(n)
        starR = FloatArray(n)
        starPh = FloatArray(n)
        for (i in 0 until n) {
            starX[i] = w * (0.04f + rnd.nextFloat() * 0.92f)
            starY[i] = rnd.nextFloat() * hy * 0.9f
            starR[i] = (0.5f + rnd.nextFloat() * 1.1f) * density
            starPh[i] = rnd.nextFloat()
        }
    }

    private fun smooth(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    /** Warna matahari bergeser: jingga kemerahan dekat horizon, kuning hangat saat tinggi. */
    private fun updateSunShader() {
        if (abs(rise - shaderRise) < 0.003f) return
        shaderRise = rise
        val warm = smooth(rise / 0.7f)
        sunPaint.shader = LinearGradient(
            cx, baseY - r, cx, baseY + r,
            mix(DEEP_TOP, AMBER, warm), mix(DEEP_BOT, ROSE, warm),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        if (r <= 0f) return
        val w = width.toFloat()
        updateSunShader()

        // langit: bintang, cahaya horizon, bara penanda tempat matahari terbit, lalu matahari
        c.save()
        c.clipRect(0f, 0f, w, hy)
        drawStars(c)
        if (rise > 0.01f) {
            domePaint.alpha = (255 * rise).toInt()
            c.drawCircle(cx, hy, w * 0.5f, domePaint)
        }
        if (rise < 0.99f) {
            val pulse = 0.5f + 0.5f * sin(spin * 2f * PI.toFloat())
            emberPaint.alpha = (255 * (1f - rise) * (0.5f + 0.5f * pulse)).toInt()
            c.drawCircle(cx, hy, r, emberPaint)
        }
        drawSun(c, 1f)
        c.restore()

        // pantulan di bawah horizon
        c.save()
        c.clipRect(0f, hy, w, height.toFloat())
        c.scale(1f, -1f, cx, hy)
        drawSun(c, 0.22f)
        c.restore()

        c.drawLine(0f, hy, w, hy, linePaint)
    }

    private fun drawStars(c: Canvas) {
        val night = 1f - rise
        if (night < 0.02f) return
        for (i in starX.indices) {
            val tw = 0.55f + 0.45f * sin((spin + starPh[i]) * 2f * PI.toFloat())
            starPaint.alpha = (255 * night * night * tw).toInt()
            c.drawCircle(starX[i], starY[i], starR[i], starPaint)
        }
    }

    private fun drawSun(c: Canvas, k: Float) {
        val dy = (1f - rise) * (offY - baseY)
        val scale = 1f + 0.12f * (1f - rise)
        val glow = ((rise - 0.15f) / 0.85f).coerceIn(0f, 1f)
        c.save()
        c.translate(0f, dy)
        c.scale(scale, scale, cx, baseY)
        if (glow > 0.01f) {
            haloPaint.alpha = (255 * glow * k).toInt()
            c.drawCircle(cx, baseY, r * 2.3f, haloPaint)

            rayPaint.alpha = (190 * glow * k).toInt()
            val shift = Math.toRadians((spin * 15f).toDouble())
            for (i in 0 until 24) {
                val a = shift + i * (Math.PI * 2.0 / 24.0)
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                val r1 = r * 1.2f
                val r2 = r * (if (i % 2 == 0) 1.5f else 1.36f)
                c.drawLine(cx + ca * r1, baseY + sa * r1, cx + ca * r2, baseY + sa * r2, rayPaint)
            }
        }
        sunPaint.alpha = (255 * k).toInt()
        c.drawCircle(cx, baseY, r, sunPaint)
        c.restore()
    }
}
