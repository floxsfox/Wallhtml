"""Membuat musik latar dan efek suara untuk video promo wallhtml (tanpa file eksternal).

Jalankan: python3 tools/make_audio.py   (butuh numpy dan scipy)
Tempo 120 BPM: satu beat = 15 frame pada 30 fps, jadi semua pergantian scene jatuh tepat di beat.
"""
import os

import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "audio")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(42)


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def save(name, x):
    x = np.asarray(x, dtype=np.float64)
    peak = np.max(np.abs(x)) + 1e-9
    if peak > 0.95:
        x = x * (0.95 / peak)
    wavfile.write(os.path.join(OUT, name), SR, (x * 32767).astype(np.int16))
    print(f"{name:14s} {len(x) / SR:5.2f}s peak {np.max(np.abs(x)):.2f}")


def bell(freq, dur, decay=0.6, gain=1.0):
    t = tt(dur)
    parts = [(1.0, 1.0, 1.0), (2.0, 0.45, 0.7), (2.76, 0.30, 0.5), (5.40, 0.12, 0.3)]
    x = np.zeros_like(t)
    for ratio, amp, dk in parts:
        x += amp * np.sin(2 * np.pi * freq * ratio * t) * np.exp(-t / (decay * dk))
    x *= np.minimum(t / 0.004, 1.0)
    return gain * x / 1.6


def pluck(freq, dur, decay=0.3, gain=1.0):
    t = tt(dur)
    x = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(2 * np.pi * freq * 2 * t) + 0.12 * np.sin(2 * np.pi * freq * 3 * t)
    x *= np.exp(-t / decay) * np.minimum(t / 0.003, 1.0)
    return gain * x / 1.5


def kick(dur=0.38, gain=1.0):
    t = tt(dur)
    f = 45 + 110 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / 0.13)
    x += 0.25 * rng.standard_normal(len(t)) * np.exp(-t / 0.004)
    return gain * x


def hat(dur=0.09, gain=1.0):
    t = tt(dur)
    n = rng.standard_normal(len(t))
    sos = signal.butter(4, 7000, "highpass", fs=SR, output="sos")
    return gain * signal.sosfilt(sos, n) * np.exp(-t / 0.018)


def clap(dur=0.22, gain=1.0):
    t = tt(dur)
    n = rng.standard_normal(len(t))
    sos = signal.butter(2, [1200, 3800], "bandpass", fs=SR, output="sos")
    env = np.exp(-t / 0.05) + 0.6 * np.exp(-np.maximum(t - 0.012, 0) / 0.04) * (t > 0.012)
    return gain * signal.sosfilt(sos, n) * env


def noise_sweep(dur, f0, f1, width=0.55, segs=28):
    """Derau yang pita frekuensinya bergeser dari f0 ke f1 (overlap-add)."""
    n = int(dur * SR)
    out = np.zeros(n)
    hop = n // segs
    win = np.hanning(hop * 2)
    for i in range(segs):
        fc = f0 * (f1 / f0) ** (i / (segs - 1))
        lo, hi = max(fc * (1 - width), 40), min(fc * (1 + width), SR / 2 - 100)
        sos = signal.butter(2, [lo, hi], "bandpass", fs=SR, output="sos")
        seg = signal.sosfilt(sos, rng.standard_normal(hop * 2))
        a = i * hop
        b = min(a + hop * 2, n)
        out[a:b] += (seg * win)[: b - a]
    return out / (np.max(np.abs(out)) + 1e-9)


def add(buf, sig, start, gain=1.0):
    i = int(start * SR)
    if i >= len(buf):
        return
    j = min(i + len(sig), len(buf))
    buf[i:j] += gain * sig[: j - i]


# ---------------------------------------------------------------- efek suara
def make_sfx():
    # whoosh teks
    d = 0.9
    t = tt(d)
    env = np.sin(np.pi * t / d) ** 1.6
    save("whoosh.wav", noise_sweep(d, 250, 4200) * env * 0.8)

    # swoosh transisi kotak: sapuan turun, lalu "thud" tepat saat layar tertutup (0.40 dtk)
    d = 0.95
    buf = np.zeros(int(d * SR))
    t = tt(0.62)
    sweep = noise_sweep(0.62, 5200, 420) * (np.minimum(t / 0.05, 1) * np.exp(-np.maximum(t - 0.30, 0) / 0.14))
    add(buf, sweep, 0.0, 0.62)
    add(buf, kick(0.45), 0.40, 0.85)
    add(buf, noise_sweep(0.35, 900, 5200) * np.hanning(int(0.35 * SR)), 0.42, 0.35)
    save("swoosh.wav", buf)

    # plink: bel pentatonik C D E G A C
    for i, m in enumerate([84, 86, 88, 91, 93, 96]):
        save(f"plink{i}.wav", bell(mtof(m), 0.7, decay=0.28, gain=0.9))

    # pop (kemunculan elemen)
    t = tt(0.22)
    f = 260 + 700 * np.exp(-t / 0.03)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05)
    x += 0.3 * rng.standard_normal(len(t)) * np.exp(-t / 0.003)
    save("pop.wav", x * 0.8)

    # click UI
    t = tt(0.12)
    x = np.sin(2 * np.pi * 2300 * t) * np.exp(-t / 0.012)
    x += 0.5 * signal.sosfilt(signal.butter(2, 3500, "highpass", fs=SR, output="sos"), rng.standard_normal(len(t))) * np.exp(-t / 0.006)
    save("click.wav", x * 0.6)

    # matahari terbit: arpeggio naik + udara
    d = 2.2
    buf = np.zeros(int(d * SR))
    for k, m in enumerate([72, 76, 79, 84, 88]):
        add(buf, bell(mtof(m), 1.4, decay=0.7, gain=0.7), 0.13 * k)
    t = tt(1.9)
    air = noise_sweep(1.9, 1500, 7000, width=0.7) * (np.sin(np.pi * (t / 1.9) ** 0.8) ** 2)
    add(buf, air, 0.0, 0.22)
    save("sunrise.wav", buf)

    # matahari terbenam: arpeggio turun, lebih lembut
    d = 2.0
    buf = np.zeros(int(d * SR))
    for k, m in enumerate([88, 84, 79, 76, 72]):
        add(buf, pluck(mtof(m), 1.0, decay=0.45, gain=0.7), 0.15 * k)
    t = tt(1.7)
    air = noise_sweep(1.7, 4500, 500, width=0.6) * (np.sin(np.pi * (t / 1.7)) ** 1.5)
    add(buf, air, 0.1, 0.2)
    save("sunset.wav", buf)

    # chime penutup
    d = 3.0
    buf = np.zeros(int(d * SR))
    for k, m in enumerate([72, 76, 79, 84]):
        add(buf, bell(mtof(m), 2.2, decay=1.3, gain=0.75), 0.17 * k)
    add(buf, bell(mtof(96), 2.4, decay=1.6, gain=0.35), 0.68)
    save("chime.wav", buf)


# ---------------------------------------------------------------- musik latar
def reverb(x, wet=0.16, rt=1.3):
    n = int(rt * SR)
    t = np.arange(n) / SR
    out = np.zeros_like(x)
    for ch in range(2):
        ir = rng.standard_normal(n) * np.exp(-t / (rt / 4.5))
        ir[: int(0.012 * SR)] *= np.linspace(0, 1, int(0.012 * SR))
        ir /= np.sqrt(np.sum(ir ** 2))
        out[:, ch] = signal.fftconvolve(x[:, ch], ir)[: len(x)]
    return x * (1 - wet) + out * wet * 1.5


def make_music():
    bpm = 120
    beat = 60 / bpm            # 0.5 dtk
    bar = beat * 4             # 2 dtk
    bars = 16
    total = bars * bar         # 32 dtk
    n = int(total * SR)
    pad = np.zeros((n, 2))
    arp = np.zeros((n, 2))
    bass = np.zeros(n)
    drums = np.zeros(n)
    kick_times = []

    chords = {
        "C": dict(pad=[60, 64, 67], bass=48, arp=[72, 76, 79, 84]),
        "G": dict(pad=[59, 62, 67], bass=43, arp=[71, 74, 79, 83]),
        "Am": dict(pad=[57, 60, 64], bass=45, arp=[69, 72, 76, 81]),
        "F": dict(pad=[57, 60, 65], bass=41, arp=[69, 72, 77, 81]),
    }
    prog = ["C", "G", "Am", "F"] * 4
    pattern = [0, 1, 2, 1, 3, 2, 1, 2]

    for b in range(bars):
        c = chords[prog[b]]
        t0 = b * bar

        # pad: triad lembut, serang pelan, sedikit detune kiri/kanan
        tp = tt(bar + 0.6)
        env = np.minimum(tp / 0.5, 1.0) * np.where(tp < bar, 1.0, np.exp(-(tp - bar) / 0.25))
        for m in c["pad"]:
            for ch, det in ((0, 0.997), (1, 1.003)):
                f = mtof(m) * det
                w = np.sin(2 * np.pi * f * tp) + 0.25 * np.sin(2 * np.pi * 2 * f * tp) + 0.08 * np.sin(2 * np.pi * 3 * f * tp)
                i = int(t0 * SR)
                j = min(i + len(tp), n)
                pad[i:j, ch] += (0.05 * w * env)[: j - i]

        # bass: nada akar tiap beat (mulai bar 3); harmonik agar terdengar di speaker ponsel
        if 2 <= b <= 14:
            for k in range(4):
                tb = tt(beat * 0.95)
                f = mtof(c["bass"])
                w = np.sin(2 * np.pi * f * tb) + 0.5 * np.sin(2 * np.pi * 2 * f * tb) + 0.2 * np.sin(2 * np.pi * 3 * f * tb)
                add(bass, w * np.exp(-tb / 0.32) * np.minimum(tb / 0.01, 1), t0 + k * beat, 0.16)

        # arpeggio pluck delapanan
        for k in range(8):
            if b == 0 and k not in (0, 3, 5):
                continue
            if b == 1 and k % 2 == 1 and k not in (3, 7):
                continue
            m = c["arp"][pattern[k]]
            accent = 1.0 if k % 4 == 0 else 0.72
            sig = pluck(mtof(m), 0.7, decay=0.28, gain=0.3 * accent)
            pan = 0.35 if k % 2 == 0 else -0.35
            i = int((t0 + k * beat / 2) * SR)
            j = min(i + len(sig), n)
            arp[i:j, 0] += (sig * (1 - pan) / 2 * 1.4)[: j - i]
            arp[i:j, 1] += (sig * (1 + pan) / 2 * 1.4)[: j - i]

        # drum
        if 2 <= b <= 14:
            for k in range(4):
                add(drums, kick(0.38), t0 + k * beat, 0.62)
                kick_times.append(t0 + k * beat)
        if 4 <= b <= 14:
            for k in range(8):
                add(drums, hat(0.09), t0 + k * beat / 2, 0.07 if k % 2 == 0 else 0.11)
            for k in (1, 3):
                add(drums, clap(0.22), t0 + k * beat, 0.22)

    # sidechain: pad dan arp merunduk sesaat setiap kick
    duck = np.ones(n)
    tk = tt(0.3)
    shape = 1 - 0.38 * np.exp(-tk / 0.1)
    for kt in kick_times:
        i = int(kt * SR)
        j = min(i + len(shape), n)
        duck[i:j] = np.minimum(duck[i:j], shape[: j - i])
    pad *= duck[:, None]
    arp *= duck[:, None]

    # penutup: bar terakhir menyisakan bel pelan di atas akor C
    last = (bars - 1) * bar
    for k, m in enumerate([72, 76, 79, 84]):
        sig = bell(mtof(m), 2.2, decay=1.2, gain=0.16)
        i = int((last + 0.25 + k * 0.25) * SR)
        j = min(i + len(sig), n)
        arp[i:j, 0] += sig[: j - i]
        arp[i:j, 1] += sig[: j - i]

    mix = pad + arp + np.stack([bass, bass], 1) + np.stack([drums, drums], 1)
    mix = reverb(mix, wet=0.16)

    # fade in 1 dtk, fade out 2 dtk
    t = np.arange(n) / SR
    fade = np.minimum(t / 1.0, 1.0) * np.minimum((total - t) / 2.0, 1.0)
    mix *= fade[:, None]
    mix = np.tanh(mix * 1.6) / np.tanh(1.6)
    mix *= 0.85 / (np.max(np.abs(mix)) + 1e-9)
    wavfile.write(os.path.join(OUT, "music.wav"), SR, (mix * 32767).astype(np.int16))
    rms = np.sqrt(np.mean(mix ** 2))
    print(f"music.wav      {total:5.2f}s peak {np.max(np.abs(mix)):.2f} rms {rms:.3f}")


if __name__ == "__main__":
    make_sfx()
    make_music()
