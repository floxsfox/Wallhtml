import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {AppScreen} from '../AppScreen';
import {Phone3D} from '../Phone3D';
import {C, SANS, SERIF} from '../theme';
import {BlurIn, prog} from '../ui';

const TAP1 = 44;
const TAP2 = 118;
const NAME = 'Rainbow_Box_Rain_Wallpaper';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Caption: React.FC<{lines: string[]; sub?: string; fadeIn: number; fadeOut: number}> = ({
  lines,
  sub,
  fadeIn,
  fadeOut,
}) => {
  const f = useCurrentFrame();
  const i = prog(f, fadeIn, 22);
  const o = prog(f, fadeOut, 14, Easing.in(Easing.cubic));
  const p = i * (1 - o);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: 940,
        opacity: p,
        transform: `translateY(${(1 - i) * 36 - o * 30}px)`,
        filter: p >= 1 ? undefined : `blur(${(1 - p) * 12}px)`,
      }}
    >
      {lines.map((l) => (
        <div key={l} style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 96, lineHeight: 1, color: C.ink, whiteSpace: 'nowrap'}}>
          {l}
        </div>
      ))}
      {sub ? (
        <div style={{fontFamily: SANS, fontSize: 40, color: C.muted, marginTop: 28}}>{sub}</div>
      ) : null}
    </div>
  );
};

const FpsPill: React.FC<{label: string; on: boolean}> = ({label, on}) => (
  <div
    style={{
      fontFamily: SANS,
      fontWeight: 600,
      fontSize: 30,
      padding: '14px 30px',
      borderRadius: 99,
      background: on ? C.amber : C.surface,
      color: on ? C.dusk : C.muted,
      border: on ? 'none' : `2px solid ${C.line}`,
    }}
  >
    {label}
  </div>
);

/** Adegan 4: layar aplikasi, ketuk matahari untuk menyalakan dan mematikan wallpaper. */
export const ToggleScene: React.FC = () => {
  const f = useCurrentFrame();
  const up = interpolate(f, [TAP1 + 2, TAP1 + 59], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const down = interpolate(f, [TAP2 + 2, TAP2 + 47], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const rise = up * (1 - down);

  const on = f >= TAP1 && f < TAP2;
  const title = on ? 'Menyala' : 'Mati';
  const sub = on ? `Memutar “${NAME}”` : 'Ketuk matahari untuk menyalakan wallpaper';

  const ripples = [
    prog(f, TAP1, 20, Easing.linear) * (f >= TAP1 ? 1 : 0),
    prog(f, TAP2, 20, Easing.linear) * (f >= TAP2 ? 1 : 0),
  ].map((p) => (p >= 1 ? 0 : p));

  const ry = 26 - (f / 195) * 40;
  const rx = 6 + Math.sin(f / 40) * 1.5;
  const floatY = Math.sin(f / 24) * 8;
  const fpsOn = f >= 168 ? 0 : 1;

  return (
    <AbsoluteFill style={{background: `radial-gradient(1100px 900px at 28% 50%, #2a2660 0%, ${C.dusk} 64%)`}}>
      <div style={{position: 'absolute', left: 320, top: 140}}>
        <Phone3D rx={rx} ry={ry} scale={1.12} y={floatY} gloss={0.9 - f / 195 * 0.7}>
          <AppScreen rise={rise} frame={f} title={title} sub={sub} ripples={ripples} />
        </Phone3D>
      </div>

      <div style={{position: 'absolute', left: 940, top: 300, width: 940, height: 420}}>
        <Caption lines={['Satu ketukan,', 'wallpaper menyala.']} fadeIn={28} fadeOut={102} />
        <Caption
          lines={['Ketuk lagi,', 'matahari terbenam.']}
          sub="WebView berhenti. Baterai istirahat."
          fadeIn={122}
          fadeOut={999}
        />
      </div>

      <BlurIn start={146} y={24} style={{position: 'absolute', left: 960, top: 800}}>
        <div style={{fontFamily: SANS, fontSize: 30, color: C.muted, marginBottom: 18}}>
          Atur kelancaran sesuai baterai
        </div>
        <div style={{display: 'flex', gap: 16}}>
          <FpsPill label="Hemat  20 fps" on={fpsOn === 0} />
          <FpsPill label="Normal  30 fps" on={fpsOn === 1} />
          <FpsPill label="Halus  60 fps" on={false} />
        </div>
      </BlurIn>
    </AbsoluteFill>
  );
};
