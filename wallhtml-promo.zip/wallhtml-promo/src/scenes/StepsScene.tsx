import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FileIcon, SparkIcon, SunIcon} from '../Icons';
import {C, SANS, SERIF} from '../theme';
import {BlurIn} from '../ui';

const STEPS = [
  {n: '1', title: 'Tambah', desc: 'File .html, .zip, atau link web.', icon: <FileIcon size={64} />},
  {n: '2', title: 'Pasang', desc: 'Satu ketukan ke layar konfirmasi sistem.', icon: <SunIcon size={64} />},
  {n: '3', title: 'Selesai', desc: 'Beranda kamu jadi hidup.', icon: <SparkIcon size={64} />},
];

/** Adegan 5: tiga langkah memakai aplikasi, kartu 3D masuk bergantian. */
export const StepsScene: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  return (
    <AbsoluteFill style={{background: `radial-gradient(1400px 900px at 50% 60%, #2a2660 0%, ${C.dusk} 65%)`}}>
      <BlurIn start={4} style={{position: 'absolute', top: 88, left: 0, right: 0, textAlign: 'center'}}>
        <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 118, lineHeight: 1, color: C.ink}}>Tiga langkah.</div>
      </BlurIn>

      <div
        style={{
          position: 'absolute',
          top: 290,
          left: 0,
          right: 0,
          display: 'flex',
          justifyContent: 'center',
          gap: 56,
          perspective: 2000,
        }}
      >
        {STEPS.map((s, i) => {
          const p = spring({frame: f - (14 + i * 12), fps, config: {damping: 14, stiffness: 110}});
          const tilt = (1 - i) * 14;
          const float = Math.sin((f + i * 12) / 22) * 8;
          return (
            <div
              key={s.n}
              style={{
                width: 500,
                height: 520,
                borderRadius: 40,
                background: C.surface,
                border: `2px solid ${C.line}`,
                position: 'relative',
                boxShadow: '0 40px 80px rgba(0,0,0,0.45)',
                opacity: Math.min(1, p * 1.5),
                transform: `translateY(${(1 - p) * 120 + float}px) rotateX(${(1 - p) * -70}deg) rotateY(${tilt}deg)`,
              }}
            >
              <div style={{position: 'absolute', left: 44, top: 14, fontFamily: SERIF, fontStyle: 'italic', fontSize: 210, lineHeight: 1, color: C.amber}}>
                {s.n}
              </div>
              <div style={{position: 'absolute', right: 44, top: 52, color: C.rose}}>{s.icon}</div>
              <div style={{position: 'absolute', left: 44, right: 44, bottom: 52}}>
                <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 60, color: C.ink}}>{s.title}</div>
                <div style={{fontFamily: SANS, fontSize: 31, color: C.muted, marginTop: 10, lineHeight: 1.3}}>{s.desc}</div>
              </div>
            </div>
          );
        })}
      </div>

      <BlurIn start={72} style={{position: 'absolute', bottom: 70, left: 0, right: 0, textAlign: 'center'}}>
        <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 38, color: C.ink, opacity: 0.85}}>
          Tanpa izin penyimpanan. Tanpa root.
        </div>
      </BlurIn>
    </AbsoluteFill>
  );
};
