import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {AppIcon} from '../Icons';
import {SunScene} from '../SunScene';
import {C, SANS, SERIF} from '../theme';
import {BlurIn} from '../ui';

/** Adegan 2: matahari terbit di atas air, nama dan ikon aplikasi muncul. */
export const Brand: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rise = interpolate(f, [8, 72], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const pop = spring({frame: f - 30, fps, config: {damping: 12, stiffness: 120}});

  return (
    <AbsoluteFill style={{background: C.dusk}}>
      <div style={{position: 'absolute', left: (1920 - 1000) / 2, top: 30}}>
        <SunScene rise={rise} frame={f} width={1000} id="brand" />
      </div>

      <div
        style={{
          position: 'absolute',
          top: 690,
          left: 0,
          right: 0,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 44,
        }}
      >
        <div style={{perspective: 700}}>
          <div
            style={{
              opacity: Math.min(1, pop * 1.4),
              transform: `rotateY(${(1 - pop) * 90}deg) scale(${0.5 + 0.5 * pop})`,
              filter: 'drop-shadow(0 18px 30px rgba(0,0,0,0.45))',
            }}
          >
            <AppIcon size={170} id="brand-icon" />
          </div>
        </div>
        <BlurIn start={46}>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 230, lineHeight: 1, color: C.ink, letterSpacing: '-0.01em'}}>
            wallhtml
          </div>
        </BlurIn>
      </div>

      <BlurIn start={72} style={{position: 'absolute', top: 925, left: 0, right: 0, textAlign: 'center'}}>
        <div style={{fontFamily: SANS, fontWeight: 400, fontSize: 46, color: C.muted}}>
          File HTML atau halaman web jadi wallpaper hidup.
        </div>
      </BlurIn>
    </AbsoluteFill>
  );
};
