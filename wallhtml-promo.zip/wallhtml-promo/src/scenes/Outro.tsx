import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {AppIcon, Clover} from '../Icons';
import {OUTRO_RAIN, OUTRO_WARM, RainWall} from '../RainWall';
import {C, SANS, SERIF} from '../theme';
import {BlurIn, prog} from '../ui';

/** Adegan 6: penutup. Kredit pembuat baru muncul di akhir. */
export const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: f - 4, fps, config: {damping: 12, stiffness: 120}});
  const credit = prog(f, 78, 26);
  const clover = spring({frame: f - 82, fps, config: {damping: 9, stiffness: 120}});
  const line = prog(f, 72, 24);

  return (
    <AbsoluteFill style={{background: '#000'}}>
      <RainWall cfg={OUTRO_RAIN} t={f + OUTRO_WARM} />
      <AbsoluteFill style={{background: 'rgba(21,19,46,0.78)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(900px 600px at 50% 46%, rgba(255,192,107,0.16), rgba(0,0,0,0) 70%)'}} />

      <div
        style={{
          position: 'absolute',
          top: 160,
          left: 0,
          right: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <div style={{perspective: 700}}>
          <div
            style={{
              opacity: Math.min(1, pop * 1.4),
              transform: `rotateY(${(1 - pop) * 90}deg) scale(${0.5 + 0.5 * pop})`,
              filter: 'drop-shadow(0 18px 30px rgba(0,0,0,0.5))',
            }}
          >
            <AppIcon size={190} id="outro-icon" />
          </div>
        </div>
        <BlurIn start={14} style={{marginTop: 26}}>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 260, lineHeight: 1, color: C.ink}}>wallhtml</div>
        </BlurIn>
        <BlurIn start={30} style={{marginTop: 18}}>
          <div style={{fontFamily: SANS, fontSize: 48, color: C.muted}}>Wallpaper hidup dari HTML dan web.</div>
        </BlurIn>
      </div>

      <div
        style={{
          position: 'absolute',
          bottom: 96,
          left: 0,
          right: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 24,
        }}
      >
        <div style={{height: 2, width: 320 * line, background: C.amber, opacity: 0.8}} />
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 20,
            opacity: credit,
            transform: `translateY(${(1 - credit) * 22}px)`,
            filter: credit >= 1 ? undefined : `blur(${(1 - credit) * 10}px)`,
          }}
        >
          <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 52, color: C.ink, letterSpacing: '0.01em'}}>
            by made eliojioDev
          </span>
          <div style={{transform: `scale(${clover}) rotate(${(1 - clover) * -120}deg)`}}>
            <Clover size={64} />
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
