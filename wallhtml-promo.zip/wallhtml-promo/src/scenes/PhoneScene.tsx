import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FileIcon, LinkIcon, SparkIcon} from '../Icons';
import {HomeScreen} from '../HomeScreen';
import {Phone3D} from '../Phone3D';
import {PHONE_RAIN, PHONE_WARM, RainWall} from '../RainWall';
import {C, RAINBOW, SANS, SERIF, mulberry32} from '../theme';
import {BlurIn, prog} from '../ui';

const DRIFT = (() => {
  const rnd = mulberry32(31);
  return Array.from({length: 26}, () => {
    const x = rnd() * 1920;
    const y0 = rnd() * 1200;
    const s = 14 + Math.floor(rnd() * 3) * 10;
    const v = 0.35 + rnd() * 0.6;
    const color = RAINBOW[Math.floor(rnd() * RAINBOW.length)];
    return {x, y0, s, v, color};
  });
})();

const Chip: React.FC<{start: number; icon: React.ReactNode; text: string}> = ({start, icon, text}) => (
  <BlurIn start={start} y={26} style={{marginTop: 22}}>
    <div
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 22,
        padding: '14px 40px 14px 16px',
        borderRadius: 99,
        background: C.surface,
        border: `2px solid ${C.line}`,
      }}
    >
      <div
        style={{
          width: 62,
          height: 62,
          borderRadius: '50%',
          background: C.amber,
          color: C.dusk,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {icon}
      </div>
      <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 40, color: C.ink}}>{text}</span>
    </div>
  </BlurIn>
);

/** Adegan 3: ponsel 3D berputar, wallpaper Rainbow Box Rain berjalan di beranda. */
export const PhoneScene: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame: f, fps, config: {damping: 200}, durationInFrames: 40});
  const ry = -34 + (f / 255) * 48 + (1 - enter) * 60;
  const rx = 7 + Math.sin(f / 45) * 2;
  const floatY = Math.sin(f / 26) * 9;
  const card = prog(f, 40, 24);
  const pulse = 0.55 + 0.45 * Math.sin(f / 7);

  return (
    <AbsoluteFill style={{background: `radial-gradient(1200px 900px at 72% 50%, #2a2660 0%, ${C.dusk} 62%)`}}>
      {DRIFT.map((d, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: d.x,
            top: ((d.y0 - f * d.v * 2) % 1240 + 1240) % 1240 - 80,
            width: d.s,
            height: d.s,
            background: d.color,
            opacity: 0.13,
          }}
        />
      ))}

      <div style={{position: 'absolute', left: 130, top: 168, width: 900}}>
        <BlurIn start={6}>
          <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 34, color: C.amber}}>
            Contoh wallpaper: Rainbow Box Rain
          </div>
        </BlurIn>
        <BlurIn start={14} style={{marginTop: 10}}>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 170, lineHeight: 0.96, color: C.ink}}>Pasang di</div>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 170, lineHeight: 0.96, color: C.ink}}>beranda.</div>
        </BlurIn>
        <div style={{marginTop: 26}}>
          <Chip start={64} icon={<FileIcon size={34} />} text="Upload file .html atau .zip" />
          <Chip start={100} icon={<LinkIcon size={34} />} text="Atau tempel link web" />
          <Chip start={136} icon={<SparkIcon size={34} />} text="WebGL dan video jalan penuh" />
        </div>
      </div>

      <div style={{position: 'absolute', left: 1180, top: 140}}>
        <Phone3D
          rx={rx}
          ry={ry}
          scale={1.12}
          x={(1 - enter) * 520}
          y={floatY}
          gloss={0.15 + f / 255 * 0.8}
          layers={
            <div
              style={{
                position: 'absolute',
                left: -190,
                bottom: 150,
                transform: 'translateZ(120px)',
                opacity: card,
                filter: card >= 1 ? undefined : `blur(${(1 - card) * 10}px)`,
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 16,
                  padding: '18px 26px',
                  borderRadius: 26,
                  background: C.surface,
                  border: `2px solid ${C.amber}`,
                  boxShadow: '0 30px 60px rgba(0,0,0,0.5)',
                }}
              >
                <div
                  style={{
                    fontFamily: SANS,
                    fontWeight: 600,
                    fontSize: 20,
                    padding: '6px 14px',
                    borderRadius: 99,
                    background: C.amber,
                    color: C.dusk,
                  }}
                >
                  html
                </div>
                <div>
                  <div style={{fontFamily: SANS, fontSize: 26, color: C.ink}}>Rainbow Box Rain</div>
                  <div style={{fontFamily: SANS, fontSize: 19, color: C.muted, display: 'flex', alignItems: 'center', gap: 8}}>
                    <span
                      style={{width: 10, height: 10, borderRadius: '50%', background: C.green, opacity: pulse, display: 'inline-block'}}
                    />
                    wallpaper aktif
                  </div>
                </div>
              </div>
            </div>
          }
        >
          <RainWall cfg={PHONE_RAIN} t={f + PHONE_WARM} />
          <HomeScreen />
        </Phone3D>
      </div>
    </AbsoluteFill>
  );
};
