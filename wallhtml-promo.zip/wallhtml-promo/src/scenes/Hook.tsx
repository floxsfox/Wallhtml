import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {HOOK_RAIN, HOOK_WARM, RainWall} from '../RainWall';
import {C, SANS, SERIF} from '../theme';
import {BlurIn} from '../ui';

/** Adegan 1: kotak warna-warni jatuh dan menumpuk, lalu kalimat pembuka. */
export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const out = interpolate(f, [92, 114], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });

  return (
    <AbsoluteFill style={{background: '#000'}}>
      <RainWall cfg={HOOK_RAIN} t={f + HOOK_WARM} />
      <AbsoluteFill
        style={{
          background:
            'linear-gradient(180deg, rgba(0,0,0,0.84) 0%, rgba(0,0,0,0.58) 40%, rgba(0,0,0,0) 72%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: 130,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: 1 - out,
          transform: `translateY(${-out * 50}px)`,
        }}
      >
        <BlurIn start={8}>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 200, lineHeight: 1, color: '#fff', textShadow: '0 4px 40px rgba(0,0,0,0.6)'}}>
            Wallpaper kamu
          </div>
        </BlurIn>
        <BlurIn start={24} style={{marginTop: 18}}>
          <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 34}}>
            <span style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 200, lineHeight: 1, color: '#fff', textShadow: '0 4px 40px rgba(0,0,0,0.6)'}}>
              bisa jadi
            </span>
            <span
              style={{
                fontFamily: SANS,
                fontWeight: 800,
                fontSize: 128,
                lineHeight: 1,
                color: C.amber,
                border: `6px solid ${C.amber}`,
                borderRadius: 30,
                padding: '10px 36px 18px',
                background: 'rgba(0,0,0,0.45)',
              }}
            >
              {'<html/>'}
            </span>
          </div>
        </BlurIn>
      </div>
    </AbsoluteFill>
  );
};
