import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {BoxTransition} from './BoxTransition';
import {Soundtrack} from './Soundtrack';
import {CUT, TOTAL, TRANS, TRANS_HALF} from './theme';
import {Brand} from './scenes/Brand';
import {Hook} from './scenes/Hook';
import {Outro} from './scenes/Outro';
import {PhoneScene} from './scenes/PhoneScene';
import {StepsScene} from './scenes/StepsScene';
import {ToggleScene} from './scenes/ToggleScene';

const SCENES: {from: number; to: number; node: React.ReactNode}[] = [
  {from: 0, to: CUT.brand, node: <Hook />},
  {from: CUT.brand, to: CUT.phone, node: <Brand />},
  {from: CUT.phone, to: CUT.toggle, node: <PhoneScene />},
  {from: CUT.toggle, to: CUT.steps, node: <ToggleScene />},
  {from: CUT.steps, to: CUT.outro, node: <StepsScene />},
  {from: CUT.outro, to: TOTAL, node: <Outro />},
];

/**
 * Video promo wallhtml, 16:9 (1920x1080), 30 fps, 32 detik.
 * 1 Hook hujan kotak -> 2 Brand matahari terbit -> 3 Ponsel 3D -> 4 Toggle on/off -> 5 Tiga langkah -> 6 Penutup.
 * Antar scene: transisi kotak warna-warni (BoxTransition) yang menutupi titik pergantian.
 */
export const Promo: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((s) => (
      <Sequence key={s.from} from={s.from} durationInFrames={s.to - s.from}>
        {s.node}
      </Sequence>
    ))}
    {Object.values(CUT).map((cut, i) => (
      <Sequence key={cut} from={cut - TRANS_HALF} durationInFrames={TRANS}>
        <BoxTransition seed={i + 3} />
      </Sequence>
    ))}
    <Soundtrack />
  </AbsoluteFill>
);
