import React from 'react';

export const PHONE_W = 380;
export const PHONE_H = 800;
const R = 56;
const BEZEL = 12;

/**
 * Ponsel 3D dengan CSS transform: bingkai depan + belasan lapisan tipis di belakangnya
 * untuk memberi ketebalan, jadi terlihat sungguhan saat berputar.
 * Layar berukuran (PHONE_W - 24) x (PHONE_H - 24) = 356 x 776.
 */
export const Phone3D: React.FC<{
  rx: number;
  ry: number;
  rz?: number;
  scale?: number;
  x?: number;
  y?: number;
  gloss?: number;
  layers?: React.ReactNode;
  children: React.ReactNode;
}> = ({rx, ry, rz = 0, scale = 1, x = 0, y = 0, gloss = 0.5, layers, children}) => {
  const slabs = Array.from({length: 12}, (_, i) => i);
  return (
    <div style={{width: PHONE_W, height: PHONE_H, perspective: 2600, position: 'relative'}}>
      {/* bayangan di lantai */}
      <div
        style={{
          position: 'absolute',
          left: '50%',
          bottom: -62,
          width: 360,
          height: 70,
          marginLeft: -180,
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.62), rgba(0,0,0,0) 70%)',
          filter: 'blur(10px)',
          transform: `translate(${x - ry * 2.2}px, ${y * 0.4}px) scale(${scale})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          transformStyle: 'preserve-3d',
          transform: `translate(${x}px, ${y}px) rotateX(${rx}deg) rotateY(${ry}deg) rotateZ(${rz}deg) scale(${scale})`,
        }}
      >
        {slabs.map((i) => (
          <div
            key={i}
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: R,
              background: i % 2 ? '#1a1838' : '#2a2754',
              transform: `translateZ(${-(i + 1) * 1.5}px)`,
            }}
          />
        ))}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: R,
            background: 'linear-gradient(145deg, #4a467f 0%, #1d1b3b 45%, #2b2859 100%)',
            boxShadow: 'inset 0 0 0 2px rgba(255,255,255,0.14), inset 0 0 18px rgba(0,0,0,0.5)',
            transform: 'translateZ(0.5px)',
          }}
        >
          <div
            style={{
              position: 'absolute',
              inset: BEZEL,
              borderRadius: R - BEZEL,
              overflow: 'hidden',
              background: '#000',
            }}
          >
            {children}
            <div
              style={{
                position: 'absolute',
                inset: 0,
                background:
                  'linear-gradient(115deg, rgba(255,255,255,0) 20%, rgba(255,255,255,0.13) 34%, rgba(255,255,255,0) 48%)',
                backgroundSize: '260% 100%',
                backgroundPosition: `${gloss * 100}% 0`,
                pointerEvents: 'none',
              }}
            />
          </div>
          <div
            style={{
              position: 'absolute',
              top: BEZEL + 14,
              left: '50%',
              width: 16,
              height: 16,
              marginLeft: -8,
              borderRadius: '50%',
              background: '#05050a',
              boxShadow: '0 0 0 2px #1b1936',
            }}
          />
        </div>
        {layers}
      </div>
    </div>
  );
};
