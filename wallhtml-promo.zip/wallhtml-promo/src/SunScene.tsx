import React from 'react';
import {C, DEEP_BOT, DEEP_TOP, clamp01, mixHex, mulberry32, smooth} from './theme';

// Matahari terbit/terbenam seperti tombol di aplikasi (SunView), digambar ulang dalam SVG.
const VW = 316;
const VH = 270;

const STARS = (() => {
  const rnd = mulberry32(7);
  const hy = VH * 0.7;
  return Array.from({length: 44}, () => {
    const x = VW * (0.04 + rnd() * 0.92);
    const y = rnd() * hy * 0.9;
    const r = 0.5 + rnd() * 1.1;
    const ph = rnd();
    return {x, y, r, ph};
  });
})();

export const SunScene: React.FC<{rise: number; frame: number; width: number; id: string}> = ({
  rise,
  frame,
  width,
  id,
}) => {
  const cx = VW / 2;
  const hy = VH * 0.7;
  const r = Math.min(VW, VH) * 0.26;
  const baseY = hy - r * 1.2;
  const offY = hy + r * 1.1;

  const warm = smooth(rise / 0.7);
  const top = mixHex(DEEP_TOP, C.amber, warm);
  const bot = mixHex(DEEP_BOT, C.rose, warm);
  const dy = (1 - rise) * (offY - baseY);
  const sc = 1 + 0.12 * (1 - rise);
  const glow = clamp01((rise - 0.15) / 0.85);
  const spin = (frame % 180) / 180;
  const night = 1 - rise;
  const pulse = 0.5 + 0.5 * Math.sin(spin * 2 * Math.PI);

  const shift = spin * (Math.PI / 12);
  const rays = Array.from({length: 24}, (_, i) => {
    const a = shift + i * ((Math.PI * 2) / 24);
    const r1 = r * 1.2;
    const r2 = r * (i % 2 === 0 ? 1.5 : 1.36);
    return (
      <line
        key={i}
        x1={cx + Math.cos(a) * r1}
        y1={baseY + Math.sin(a) * r1}
        x2={cx + Math.cos(a) * r2}
        y2={baseY + Math.sin(a) * r2}
      />
    );
  });

  const sunGroup = (k: number) => (
    <g
      transform={`translate(0 ${dy}) translate(${cx} ${baseY}) scale(${sc}) translate(${-cx} ${-baseY})`}
    >
      {glow > 0.01 ? (
        <circle cx={cx} cy={baseY} r={r * 2.3} fill={`url(#${id}-halo)`} opacity={glow * k} />
      ) : null}
      {glow > 0.01 ? (
        <g stroke={C.amber} strokeWidth={2.6} strokeLinecap="round" opacity={0.75 * glow * k}>
          {rays}
        </g>
      ) : null}
      <circle cx={cx} cy={baseY} r={r} fill={`url(#${id}-sun)`} opacity={k} />
    </g>
  );

  return (
    <svg width={width} height={(width * VH) / VW} viewBox={`0 0 ${VW} ${VH}`} style={{display: 'block', overflow: 'visible'}}>
      <defs>
        <linearGradient id={`${id}-sun`} gradientUnits="userSpaceOnUse" x1={cx} y1={baseY - r} x2={cx} y2={baseY + r}>
          <stop offset="0" stopColor={top} />
          <stop offset="1" stopColor={bot} />
        </linearGradient>
        <radialGradient id={`${id}-halo`} gradientUnits="userSpaceOnUse" cx={cx} cy={baseY} r={r * 2.3}>
          <stop offset="0" stopColor={C.rose} stopOpacity="0.47" />
          <stop offset="0.4" stopColor={C.rose} stopOpacity="0.47" />
          <stop offset="1" stopColor={C.rose} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-dome`} gradientUnits="userSpaceOnUse" cx={cx} cy={hy} r={VW / 2}>
          <stop offset="0" stopColor={C.amber} stopOpacity="0.59" />
          <stop offset="0.45" stopColor={C.rose} stopOpacity="0.27" />
          <stop offset="1" stopColor={C.rose} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-ember`} gradientUnits="userSpaceOnUse" cx={cx} cy={hy} r={r}>
          <stop offset="0" stopColor={C.amber} stopOpacity="0.35" />
          <stop offset="1" stopColor={C.amber} stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${id}-line`} gradientUnits="userSpaceOnUse" x1="0" y1="0" x2={VW} y2="0">
          <stop offset="0" stopColor={C.line} stopOpacity="0" />
          <stop offset="0.5" stopColor={C.line} stopOpacity="1" />
          <stop offset="1" stopColor={C.line} stopOpacity="0" />
        </linearGradient>
        <clipPath id={`${id}-sky`}>
          <rect x={-VW} y={-VH} width={VW * 3} height={VH + hy} />
        </clipPath>
        <clipPath id={`${id}-water`}>
          <rect x="0" y={hy} width={VW} height={VH - hy} />
        </clipPath>
      </defs>

      <g clipPath={`url(#${id}-sky)`}>
        {night > 0.02
          ? STARS.map((s, i) => {
              const tw = 0.55 + 0.45 * Math.sin((spin + s.ph) * 2 * Math.PI);
              return <circle key={i} cx={s.x} cy={s.y} r={s.r} fill={C.ink} opacity={night * night * tw} />;
            })
          : null}
        {rise > 0.01 ? <circle cx={cx} cy={hy} r={VW / 2} fill={`url(#${id}-dome)`} opacity={rise} /> : null}
        {rise < 0.99 ? (
          <circle cx={cx} cy={hy} r={r} fill={`url(#${id}-ember)`} opacity={(1 - rise) * (0.5 + 0.5 * pulse)} />
        ) : null}
        {sunGroup(1)}
      </g>

      <g clipPath={`url(#${id}-water)`}>
        <g transform={`translate(0 ${2 * hy}) scale(1 -1)`}>{sunGroup(0.22)}</g>
      </g>

      <line x1="0" y1={hy} x2={VW} y2={hy} stroke={`url(#${id}-line)`} strokeWidth="1.5" />
    </svg>
  );
};
