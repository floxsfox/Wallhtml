import React, {useLayoutEffect, useMemo, useRef} from 'react';
import {RAINBOW, mulberry32} from './theme';

/**
 * Hujan kotak ala wallpaper Rainbow Box Rain, dibuat deterministik supaya setiap frame video
 * selalu sama: simulasi dihitung sekali (seed tetap), lalu posisi kotak pada frame t dihitung langsung.
 */
export type RainCfg = {
  W: number;
  H: number;
  box: number;
  seed: number;
  frames: number;
  spawn: number; // kotak baru per frame
  maxActive: number;
  speedMin: number; // px per frame
  speedRange: number;
};

type Box = {col: number; spawn: number; speed: number; color: number; land: number; row: number};
type Sim = {boxes: Box[]; cols: number; rows: number};

const cache = new Map<string, Sim>();

export const simulate = (cfg: RainCfg): Sim => {
  const key = JSON.stringify(cfg);
  const hit = cache.get(key);
  if (hit) return hit;

  const rnd = mulberry32(cfg.seed);
  const cols = Math.ceil(cfg.W / cfg.box);
  const rows = Math.ceil(cfg.H / cfg.box);
  const heights = new Array<number>(cols).fill(0);
  const pend = new Array<number>(cols).fill(0);
  const boxes: Box[] = [];
  const active: Box[] = [];
  let acc = 0;

  for (let f = 0; f < cfg.frames; f++) {
    acc += cfg.spawn;
    let n = Math.floor(acc);
    acc -= n;
    while (n > 0) {
      n--;
      if (active.length >= cfg.maxActive) break;
      let col = -1;
      for (let tries = 0; tries < 12; tries++) {
        const c = Math.floor(rnd() * cols);
        if (heights[c] + pend[c] < rows) {
          col = c;
          break;
        }
      }
      if (col < 0) continue;
      const b: Box = {
        col,
        spawn: f,
        speed: cfg.speedMin + Math.floor(rnd() * cfg.speedRange),
        color: Math.floor(rnd() * RAINBOW.length),
        land: -1,
        row: -1,
      };
      boxes.push(b);
      active.push(b);
      pend[col]++;
    }

    for (let i = active.length - 1; i >= 0; i--) {
      const b = active[i];
      const y = -cfg.box + b.speed * (f - b.spawn + 1);
      const targetRow = rows - 1 - heights[b.col];
      if (y >= targetRow * cfg.box) {
        b.land = f;
        if (targetRow >= 0) {
          b.row = targetRow;
          heights[b.col]++;
        }
        pend[b.col]--;
        active.splice(i, 1);
      }
    }
  }

  const sim = {boxes, cols, rows};
  cache.set(key, sim);
  return sim;
};

/** Daftar kotak yang mendarat di rentang waktu tertentu (untuk menyelaraskan efek suara). */
export const landingEvents = (
  cfg: RainCfg,
  from: number,
  to: number,
  minGap: number,
  max: number
): {frame: number; col: number}[] => {
  const sim = simulate(cfg);
  const sorted = sim.boxes
    .filter((b) => b.row >= 0 && b.land >= from && b.land <= to)
    .sort((a, b) => a.land - b.land);
  const out: {frame: number; col: number}[] = [];
  let last = -9999;
  for (const b of sorted) {
    if (b.land - last >= minGap) {
      out.push({frame: b.land, col: b.col});
      last = b.land;
      if (out.length >= max) break;
    }
  }
  return out;
};

export const RainWall: React.FC<{cfg: RainCfg; t: number; style?: React.CSSProperties}> = ({cfg, t, style}) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const sim = useMemo(() => simulate(cfg), [cfg]);

  useLayoutEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    const B = cfg.box;

    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, cfg.W, cfg.H);

    for (const b of sim.boxes) {
      if (b.spawn > t) break; // kotak diurutkan menurut waktu muncul
      const color = RAINBOW[b.color];
      if (b.land >= 0 && b.land <= t) {
        if (b.row < 0) continue;
        const x = b.col * B + 1;
        const y = b.row * B + 1;
        ctx.fillStyle = color;
        ctx.fillRect(x, y, B - 1, B - 1);
        const age = t - b.land;
        if (age < 5) {
          ctx.fillStyle = `rgba(255,255,255,${(1 - age / 5) * 0.55})`;
          ctx.fillRect(x, y, B - 1, B - 1);
        }
      } else {
        const y = -B + b.speed * (t - b.spawn + 1);
        ctx.fillStyle = color;
        ctx.fillRect(b.col * B + 1, y + 1, B - 1, B - 1);
      }
    }
  }, [cfg, sim, t]);

  return (
    <canvas
      ref={ref}
      width={cfg.W}
      height={cfg.H}
      style={{position: 'absolute', left: 0, top: 0, width: cfg.W, height: cfg.H, ...style}}
    />
  );
};

export const HOOK_WARM = 24;
export const HOOK_RAIN: RainCfg = {
  W: 1920, H: 1080, box: 40, seed: 11, frames: 200, spawn: 3.2, maxActive: 150, speedMin: 30, speedRange: 12,
};

export const PHONE_WARM = 700;
export const PHONE_RAIN: RainCfg = {
  W: 356, H: 776, box: 12, seed: 5, frames: 1000, spawn: 1.4, maxActive: 120, speedMin: 9, speedRange: 6,
};

export const OUTRO_WARM = 60;
export const OUTRO_RAIN: RainCfg = {
  W: 1920, H: 1080, box: 40, seed: 23, frames: 330, spawn: 3.5, maxActive: 200, speedMin: 22, speedRange: 10,
};
