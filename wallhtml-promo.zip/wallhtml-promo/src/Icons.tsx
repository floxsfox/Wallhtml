import React from 'react';
import {C} from './theme';

/** Ikon aplikasi wallhtml: matahari bergradasi dengan simbol </>. */
export const AppIcon: React.FC<{size: number; id: string}> = ({size, id}) => (
  <svg width={size} height={size} viewBox="0 0 108 108" style={{display: 'block'}}>
    <defs>
      <linearGradient id={`${id}-g`} gradientUnits="userSpaceOnUse" x1="54" y1="28" x2="54" y2="80">
        <stop offset="0" stopColor={C.amber} />
        <stop offset="1" stopColor={C.rose} />
      </linearGradient>
    </defs>
    <rect width="108" height="108" rx="28" fill={C.dusk} />
    <circle cx="54" cy="54" r="34" fill="none" stroke={C.amber} strokeOpacity="0.28" strokeWidth="1.5" />
    <circle cx="54" cy="54" r="26" fill={`url(#${id}-g)`} />
    <g stroke={C.dusk} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" fill="none">
      <path d="M47 44 L38 54 L47 64" />
      <path d="M61 44 L70 54 L61 64" />
      <path d="M57.5 41 L50.5 67" />
    </g>
  </svg>
);

/** Semanggi (pengganti emoji, supaya tampil sama di mesin render mana pun). */
export const Clover: React.FC<{size: number}> = ({size}) => {
  const leaf =
    'M0 0 C -4 -6 -16 -8 -16 -18 C -16 -26 -6 -28 0 -20 C 6 -28 16 -26 16 -18 C 16 -8 4 -6 0 0 Z';
  return (
    <svg width={size} height={size} viewBox="-32 -30 64 64" style={{display: 'block', overflow: 'visible'}}>
      <path d="M0 0 C 2 10 8 18 14 24" stroke={C.green} strokeWidth="3.4" strokeLinecap="round" fill="none" />
      {[0, 120, 240].map((a) => (
        <path key={a} d={leaf} fill={C.green} transform={`rotate(${a})`} stroke="#1c7a3d" strokeWidth="0.8" />
      ))}
    </svg>
  );
};

const stroke = {
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
} as const;

export const FileIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...stroke}>
    <path d="M6 3h8l4 4v14H6z" />
    <path d="M14 3v4h4" />
    <path d="M12 11v6M9 14h6" />
  </svg>
);

export const LinkIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...stroke}>
    <path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" />
    <path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" />
  </svg>
);

export const SparkIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...stroke}>
    <path d="M12 3l2.2 6.3L21 11.5l-6.8 2.2L12 21l-2.2-7.3L3 11.5l6.8-2.2z" />
  </svg>
);

export const SunIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...stroke}>
    <circle cx="12" cy="12" r="4.2" />
    <path d="M12 2.5v2.6M12 18.9v2.6M2.5 12h2.6M18.9 12h2.6M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8" />
  </svg>
);
