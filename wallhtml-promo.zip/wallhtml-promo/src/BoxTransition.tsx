import React, {useMemo} from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {RAINBOW, TRANS_HALF, mulberry32} from './theme';

const COLS = 16;
const ROWS = 9;
const CELL = 120;

/**
 * Transisi kotak warna-warni (motif wallpaper): kotak berputar menutup layar, lalu terbuka lagi.
 * Dipasang dalam Sequence berdurasi TRANS frame; pergantian scene terjadi tepat di tengah (frame TRANS_HALF).
 */
export const BoxTransition: React.FC<{seed: number}> = ({seed}) => {
  const frame = useCurrentFrame();
  const cells = useMemo(() => {
    const rnd = mulberry32(seed);
    const list: {c: number; r: number; color: string; d: number}[] = [];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const diag = (c * 0.55 + r * 0.9) / (COLS * 0.55 + ROWS * 0.9);
        const d = diag * 0.55 + rnd() * 0.25;
        list.push({c, r, color: RAINBOW[Math.floor(rnd() * RAINBOW.length)], d});
      }
    }
    return list;
  }, [seed]);

  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {cells.map((cell) => {
        const cover = interpolate(frame, [cell.d * 6, cell.d * 6 + 6], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
          easing: Easing.out(Easing.cubic),
        });
        const d2 = 1 - cell.d;
        const reveal = interpolate(frame, [TRANS_HALF + d2 * 6, TRANS_HALF + d2 * 6 + 6], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
          easing: Easing.in(Easing.cubic),
        });
        const s = frame < TRANS_HALF ? cover : 1 - reveal;
        if (s < 0.01) return null;
        return (
          <div
            key={`${cell.c}-${cell.r}`}
            style={{
              position: 'absolute',
              left: cell.c * CELL,
              top: cell.r * CELL,
              width: CELL + 1,
              height: CELL + 1,
              background: cell.color,
              transform: `perspective(520px) rotateY(${(1 - s) * 90}deg) scale(${0.6 + 0.4 * s})`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
