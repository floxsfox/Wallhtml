import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';

const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/** Progres 0..1 dari frame `start` selama `dur` frame. */
export const prog = (
  frame: number,
  start: number,
  dur: number,
  easing: (t: number) => number = Easing.out(Easing.cubic)
): number => interpolate(frame, [start, start + dur], [0, 1], {...clampOpts, easing});

/** Muncul dengan blur, naik pelan, dan fade. */
export const BlurIn: React.FC<{
  start: number;
  dur?: number;
  y?: number;
  blur?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({start, dur = 22, y = 36, blur = 14, style, children}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, start, dur);
  return (
    <div
      style={{
        opacity: p,
        transform: `translateY(${(1 - p) * y}px)`,
        filter: p >= 1 ? undefined : `blur(${(1 - p) * blur}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};
