import {loadFont as loadSerif} from '@remotion/google-fonts/InstrumentSerif';
import {loadFont as loadSans} from '@remotion/google-fonts/BricolageGrotesque';

// Instrument Serif (italic) untuk kalimat besar, Bricolage Grotesque untuk teks antarmuka.
const serif = loadSerif('italic', {weights: ['400'], subsets: ['latin']});
const sans = loadSans('normal', {weights: ['400', '600', '800'], subsets: ['latin']});

export const SERIF = `${serif.fontFamily}, Georgia, serif`;
export const SANS = `${sans.fontFamily}, system-ui, sans-serif`;

export const FPS = 30;
export const W = 1920;
export const H = 1080;

// Durasi total dan titik pergantian scene (frame). 120 BPM: 15 frame = 1 beat, semua titik jatuh di beat.
export const TOTAL = 960;
export const CUT = {brand: 120, phone: 255, toggle: 510, steps: 705, outro: 840};
export const TRANS = 24;
export const TRANS_HALF = 12;

export const C = {
  dusk: '#15132E',
  surface: '#201D43',
  line: '#332F66',
  ink: '#F4EFFA',
  muted: '#9B96C4',
  amber: '#FFC06B',
  rose: '#FF6F91',
  green: '#33CC66',
};

// Palet yang sama dengan wallpaper Rainbow Box Rain.
export const RAINBOW = [
  '#FF3366', '#FF9900', '#FFCC00', '#33CC66', '#00CCFF',
  '#3366FF', '#CC33FF', '#FF33CC', '#00FFCC', '#FF5050',
];

export const DEEP_TOP = '#FF8A4C';
export const DEEP_BOT = '#E5446D';

export const clamp01 = (x: number): number => Math.min(1, Math.max(0, x));

export const smooth = (x: number): number => {
  const t = clamp01(x);
  return t * t * (3 - 2 * t);
};

export const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return (): number => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const hexToRgb = (h: string): [number, number, number] => {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

export const mixHex = (a: string, b: string, t: number): string => {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  const k = clamp01(t);
  const ch = (i: number) => Math.round(A[i] + (B[i] - A[i]) * k);
  return `rgb(${ch(0)},${ch(1)},${ch(2)})`;
};
