import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {HOOK_RAIN, HOOK_WARM, landingEvents} from './RainWall';
import {CUT, TRANS_HALF} from './theme';

const src = (name: string) => staticFile(`audio/${name}`);

type Sfx = {at: number; file: string; vol: number};

// Hujan kotak di scene 1: plink pentatonik tiap kotak mendarat (dipilih agar tidak terlalu rapat).
const plinks: Sfx[] = landingEvents(HOOK_RAIN, HOOK_WARM, HOOK_WARM + 96, 6, 12).map((e) => ({
  at: e.frame - HOOK_WARM,
  file: `plink${e.col % 6}.wav`,
  vol: 0.3,
}));

// Swoosh transisi diputar 12 frame sebelum pergantian scene, jadi "thud"-nya tepat saat layar tertutup.
const transitions: Sfx[] = Object.values(CUT).map((cut) => ({
  at: cut - TRANS_HALF,
  file: 'swoosh.wav',
  vol: 0.7,
}));

const scenes: Sfx[] = [
  // scene 1
  {at: 8, file: 'whoosh.wav', vol: 0.9},
  // scene 2: matahari terbit, ikon muncul, nama muncul
  {at: CUT.brand + 8, file: 'sunrise.wav', vol: 0.7},
  {at: CUT.brand + 32, file: 'pop.wav', vol: 0.6},
  {at: CUT.brand + 46, file: 'whoosh.wav', vol: 0.5},
  // scene 3: ponsel masuk, kartu, tiga chip
  {at: CUT.phone + 2, file: 'whoosh.wav', vol: 0.8},
  {at: CUT.phone + 40, file: 'pop.wav', vol: 0.6},
  {at: CUT.phone + 64, file: 'click.wav', vol: 0.7},
  {at: CUT.phone + 100, file: 'click.wav', vol: 0.7},
  {at: CUT.phone + 136, file: 'click.wav', vol: 0.7},
  // scene 4: ketuk, matahari terbit, ketuk lagi, matahari terbenam, pilih fps
  {at: CUT.toggle + 6, file: 'whoosh.wav', vol: 0.5},
  {at: CUT.toggle + 44, file: 'click.wav', vol: 0.8},
  {at: CUT.toggle + 46, file: 'sunrise.wav', vol: 0.75},
  {at: CUT.toggle + 118, file: 'click.wav', vol: 0.8},
  {at: CUT.toggle + 120, file: 'sunset.wav', vol: 0.8},
  {at: CUT.toggle + 168, file: 'click.wav', vol: 0.7},
  // scene 5: tiga kartu
  {at: CUT.steps + 4, file: 'whoosh.wav', vol: 0.5},
  {at: CUT.steps + 14, file: 'pop.wav', vol: 0.6},
  {at: CUT.steps + 26, file: 'pop.wav', vol: 0.6},
  {at: CUT.steps + 38, file: 'pop.wav', vol: 0.6},
  // scene 6: ikon, lalu chime saat kredit muncul
  {at: CUT.outro + 6, file: 'pop.wav', vol: 0.6},
  {at: CUT.outro + 76, file: 'chime.wav', vol: 0.85},
];

export const Soundtrack: React.FC = () => (
  <>
    <Audio src={src('music.wav')} volume={0.55} />
    {[...plinks, ...transitions, ...scenes].map((s, i) => (
      <Sequence key={`${s.file}-${s.at}-${i}`} from={s.at}>
        <Audio src={src(s.file)} volume={s.vol} />
      </Sequence>
    ))}
  </>
);
