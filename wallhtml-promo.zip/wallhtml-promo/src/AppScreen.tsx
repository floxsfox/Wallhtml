import React from 'react';
import {C, SANS, SERIF} from './theme';
import {SunScene} from './SunScene';

const medium = {fontFamily: SANS, fontWeight: 600} as const;

const Tag: React.FC<{label: string; active: boolean}> = ({label, active}) => (
  <div
    style={{
      ...medium,
      fontSize: 11,
      padding: '4px 9px',
      borderRadius: 99,
      background: active ? C.amber : C.line,
      color: active ? C.dusk : C.muted,
      marginRight: 12,
    }}
  >
    {label}
  </div>
);

const Row: React.FC<{name: string; sub: string; kind: string; active: boolean}> = ({name, sub, kind, active}) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      padding: '12px 4px 12px 14px',
      borderRadius: 18,
      background: C.surface,
      border: `${active ? 2 : 1}px solid ${active ? C.amber : C.line}`,
      marginBottom: 10,
      boxSizing: 'border-box',
    }}
  >
    <Tag label={kind} active={active} />
    <div style={{flex: 1, minWidth: 0}}>
      <div
        style={{
          fontFamily: SANS,
          fontSize: 15,
          color: C.ink,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}
      >
        {name}
      </div>
      <div style={{fontFamily: SANS, fontSize: 12, color: C.muted}}>{sub}</div>
    </div>
    <div style={{width: 44, textAlign: 'center', fontSize: 24, color: C.muted, fontFamily: SANS}}>×</div>
  </div>
);

const SmallPill: React.FC<{label: string}> = ({label}) => (
  <div
    style={{
      ...medium,
      fontSize: 13,
      padding: '8px 14px',
      borderRadius: 99,
      border: `1px solid ${C.line}`,
      color: C.ink,
      marginLeft: 8,
    }}
  >
    {label}
  </div>
);

/** Salinan layar utama aplikasi (356 x 776) untuk ditampilkan di dalam ponsel 3D. */
export const AppScreen: React.FC<{
  rise: number;
  frame: number;
  title: string;
  sub: string;
  ripples: number[];
}> = ({rise, frame, title, sub, ripples}) => (
  <div
    style={{
      position: 'absolute',
      inset: 0,
      background: C.dusk,
      padding: '26px 20px 0',
      boxSizing: 'border-box',
      overflow: 'hidden',
    }}
  >
    <div style={{...medium, fontSize: 26, color: C.ink, letterSpacing: '-0.02em'}}>wallhtml</div>
    <div style={{fontFamily: SANS, fontSize: 13, color: C.muted, marginTop: 2}}>
      File HTML atau halaman web jadi wallpaper
    </div>

    <div style={{marginTop: 8, position: 'relative', width: 316}}>
      <SunScene rise={rise} frame={frame} width={316} id="app" />
      {ripples.map((p, i) =>
        p > 0 && p < 1 ? (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 158 - (22 + 56 * p),
              top: 108 - (22 + 56 * p),
              width: 2 * (22 + 56 * p),
              height: 2 * (22 + 56 * p),
              borderRadius: '50%',
              border: `3px solid ${C.ink}`,
              opacity: (1 - p) * 0.75,
            }}
          />
        ) : null
      )}
      {ripples.map((p, i) =>
        p > 0 && p < 0.6 ? (
          <div
            key={`d${i}`}
            style={{
              position: 'absolute',
              left: 158 - 14,
              top: 108 - 14,
              width: 28,
              height: 28,
              borderRadius: '50%',
              background: 'rgba(244,239,250,0.85)',
              transform: `scale(${1 - 0.25 * Math.sin((p / 0.6) * Math.PI)})`,
            }}
          />
        ) : null
      )}
    </div>

    <div
      style={{
        fontFamily: SERIF, fontStyle: 'italic',
        fontSize: 38,
        textAlign: 'center',
        color: rise > 0.5 ? C.amber : C.muted,
        marginTop: 0,
        lineHeight: 1.15,
      }}
    >
      {title}
    </div>
    <div
      style={{
        fontFamily: SANS,
        fontSize: 14,
        color: C.muted,
        textAlign: 'center',
        marginTop: 4,
        marginBottom: 20,
        minHeight: 34,
      }}
    >
      {sub}
    </div>

    <div
      style={{
        ...medium,
        height: 54,
        borderRadius: 99,
        background: C.amber,
        color: C.dusk,
        fontSize: 15,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      Pasang di beranda
    </div>

    <div style={{display: 'flex', alignItems: 'center', marginTop: 30, marginBottom: 12}}>
      <div style={{flex: 1, fontFamily: SERIF, fontStyle: 'italic', fontSize: 21, color: C.ink}}>Koleksi</div>
      <SmallPill label="Tambah file" />
      <SmallPill label="Tambah link" />
    </div>
    <Row name="Rainbow_Box_Rain_Wallpaper" sub="Tersimpan di ponsel" kind="html" active />
    <Row name="threejs-galaxy" sub="galaxy.example.com" kind="web" active={false} />
  </div>
);
