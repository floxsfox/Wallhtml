import React from 'react';
import {SANS, SERIF} from './theme';

const APPS = [
  ['#FF6F91', '#C23B63'], ['#FFC06B', '#E08A2E'], ['#33CC66', '#1F8F47'], ['#00CCFF', '#0B8DB5'],
  ['#CC33FF', '#8B1FB8'], ['#3366FF', '#1F3FB8'], ['#FF9900', '#C26A00'], ['#00FFCC', '#0AA586'],
];

const AppTile: React.FC<{a: string; b: string}> = ({a, b}) => (
  <div
    style={{
      width: 56,
      height: 56,
      borderRadius: 16,
      background: `linear-gradient(150deg, ${a}, ${b})`,
      boxShadow: '0 4px 10px rgba(0,0,0,0.35)',
    }}
  />
);

/** Tampilan beranda ponsel di atas wallpaper (layar 356 x 776). */
export const HomeScreen: React.FC = () => (
  <div style={{position: 'absolute', inset: 0, color: '#fff', fontFamily: SANS}}>
    <div
      style={{
        position: 'absolute',
        top: 16,
        left: 28,
        right: 28,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: 13,
        fontWeight: 600,
      }}
    >
      <span>9:41</span>
      <span style={{display: 'flex', gap: 8, alignItems: 'center'}}>
        <span style={{display: 'flex', gap: 2, alignItems: 'flex-end'}}>
          {[4, 6, 8, 10].map((h) => (
            <span key={h} style={{width: 3, height: h, background: '#fff', borderRadius: 1}} />
          ))}
        </span>
        <span
          style={{
            width: 22,
            height: 11,
            border: '1.5px solid #fff',
            borderRadius: 3,
            padding: 1,
            boxSizing: 'border-box',
          }}
        >
          <span style={{display: 'block', width: '70%', height: '100%', background: '#fff', borderRadius: 1}} />
        </span>
      </span>
    </div>

    <div style={{position: 'absolute', top: 76, left: 0, right: 0, textAlign: 'center'}}>
      <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 96, lineHeight: 1, textShadow: '0 2px 16px rgba(0,0,0,0.65)'}}>
        09:41
      </div>
      <div style={{fontSize: 15, fontWeight: 600, opacity: 0.88, marginTop: 4, textShadow: '0 1px 8px rgba(0,0,0,0.7)'}}>
        Senin, 9 November
      </div>
    </div>

    <div
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        bottom: 128,
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        rowGap: 22,
        justifyItems: 'center',
      }}
    >
      {APPS.map(([a, b]) => (
        <AppTile key={a} a={a} b={b} />
      ))}
    </div>

    <div
      style={{
        position: 'absolute',
        left: 16,
        right: 16,
        bottom: 22,
        height: 84,
        borderRadius: 30,
        background: 'rgba(255,255,255,0.15)',
        display: 'flex',
        justifyContent: 'space-around',
        alignItems: 'center',
      }}
    >
      {APPS.slice(0, 4).map(([a, b]) => (
        <AppTile key={a} a={b} b={a} />
      ))}
    </div>
  </div>
);
